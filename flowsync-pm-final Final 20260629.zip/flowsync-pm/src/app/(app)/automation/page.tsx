// src/app/(app)/automation/page.tsx
import { Metadata } from 'next'
import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { db } from '@/lib/db'
import { AutomationView } from '@/components/automation/AutomationView'

export const metadata: Metadata = { title: 'Automation' }

export default async function AutomationPage() {
  const session = await auth()
  if (!session?.user?.id) redirect('/auth/signin')

  const membership = await db.workspaceMember.findFirst({
    where:  { userId: session.user.id },
    select: { workspaceId:true, role:true },
  })
  if (!membership) redirect('/onboarding')

  const [rules, logs] = await Promise.all([
    db.$queryRaw`
      SELECT ar.*, u.name as creator_name
      FROM automation_rules ar
      LEFT JOIN users u ON u.id = ar.created_by_id
      WHERE ar.workspace_id = ${membership.workspaceId}
      ORDER BY ar.created_at DESC
    `.catch(() => []) as Promise<any[]>,

    db.$queryRaw`
      SELECT al.*, ar.name as rule_name
      FROM automation_logs al
      LEFT JOIN automation_rules ar ON ar.id = al.rule_id
      WHERE al.workspace_id = ${membership.workspaceId}
      ORDER BY al.created_at DESC
      LIMIT 50
    `.catch(() => []) as Promise<any[]>,
  ])

  return (
    <AutomationView
      rules={rules}
      recentLogs={logs}
      workspaceId={membership.workspaceId}
      userRole={membership.role}
    />
  )
}
