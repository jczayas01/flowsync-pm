// src/app/(app)/dashboard/page.tsx
import { Metadata } from 'next'
import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { db } from '@/lib/db'
import { DashboardView } from '@/components/dashboard/DashboardView'

export const metadata: Metadata = { title: 'Dashboard' }

export default async function DashboardPage() {
  const session = await auth()
  if (!session?.user?.id) redirect('/auth/signin')

  const membership = await db.workspaceMember.findFirst({
    where: { userId: session.user.id },
    select: { workspaceId: true, role: true },
  })
  if (!membership) redirect('/onboarding')

  const workspaceId = membership.workspaceId

  // Parallel data fetching
  const [projects, upcomingMilestones, openRisks, recentActivity] = await Promise.all([
    db.project.findMany({
      where:   { workspaceId, status: { in: ['ACTIVE','ON_HOLD'] } },
      include: {
        _count: { select: { tasks: true, risks: true } },
        members: {
          where:   { role: 'PM' as any },
          include: { user: { select: { name: true, avatarUrl: true } } },
          take: 1,
        },
      },
      orderBy: { updatedAt: 'desc' },
      take: 20,
    }),

    db.milestone.findMany({
      where: {
        project: { workspaceId },
        status:  { in: ['UPCOMING','AT_RISK'] },
        dueDate: { gte: new Date(), lte: new Date(Date.now() + 30*86400000) },
      },
      include: { project: { select: { id:true, code:true, name:true } } },
      orderBy: { dueDate: 'asc' },
      take: 10,
    }),

    db.risk.findMany({
      where:  { project: { workspaceId }, status: 'OPEN', score: { gte: 9 } },
      include:{ project: { select: { id:true, code:true, name:true } } },
      orderBy:{ score: 'desc' },
      take: 8,
    }),

    db.auditLog.findMany({
      where:   { workspaceId, action: { in: ['project.created','project.updated','risk.created','user.invited'] as any } },
      include: { user: { select: { name:true, avatarUrl:true } } },
      orderBy: { createdAt: 'desc' },
      take: 15,
    }),
  ])

  const healthCounts = {
    GREEN: projects.filter(p => p.health === 'GREEN').length,
    AMBER: projects.filter(p => p.health === 'AMBER').length,
    RED:   projects.filter(p => p.health === 'RED').length,
  }

  return (
    <DashboardView
      projects={projects as any}
      milestones={upcomingMilestones as any}
      risks={openRisks as any}
      activity={recentActivity as any}
      healthCounts={healthCounts}
      workspaceId={workspaceId}
    />
  )
}
