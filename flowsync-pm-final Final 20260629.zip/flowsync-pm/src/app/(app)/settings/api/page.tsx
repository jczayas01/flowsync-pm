// src/app/(app)/settings/api/page.tsx
import { Metadata } from "next"
import { auth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { db } from "@/lib/db"
import { ApiDocsView } from "@/components/settings/ApiDocsView"
export const metadata: Metadata = { title: "API & integrations" }
export default async function ApiPage() {
  const session = await auth()
  if(!session?.user?.id) redirect("/auth/signin")
  const m = await db.workspaceMember.findFirst({ where:{ userId:session.user.id }, select:{ workspaceId:true, role:true } })
  if(!m) redirect("/onboarding")
  let apiKeys: any[] = []
  try {
    apiKeys = await db.$queryRaw`SELECT id, name, prefix, scopes, last_used_at, created_at, is_active FROM api_keys WHERE workspace_id = ${m.workspaceId} ORDER BY created_at DESC`
  } catch { apiKeys = [] }
  return <ApiDocsView apiKeys={apiKeys} workspaceId={m.workspaceId} role={m.role} />
}
