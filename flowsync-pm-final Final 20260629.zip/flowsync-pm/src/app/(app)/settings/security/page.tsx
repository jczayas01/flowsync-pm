// src/app/(app)/settings/security/page.tsx
import { Metadata } from "next"
import { auth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { db } from "@/lib/db"
import { SecuritySettingsView } from "@/components/settings/SecuritySettingsView"
import { BAARequestFlow } from "@/components/legal/BAARequestFlow"

export const metadata: Metadata = { title: "Security" }

export default async function SecurityPage() {
  const session = await auth()
  if (!session?.user?.id) redirect("/auth/signin")

  const membership = await db.workspaceMember.findFirst({
    where: { userId: session.user.id },
    include: { workspace: { select: { id:true, plan:true, name:true } } }
  })
  if (!membership) redirect("/onboarding")

  const auditLogs = await db.auditLog.findMany({
    where:   { workspaceId: membership.workspaceId },
    include: { user: { select: { name:true, avatarUrl:true } } },
    orderBy: { createdAt: "desc" },
    take:    50,
  })

  // Check existing BAA status
  let baaState: any = { status: "none" }
  try {
    const baaLog = await db.auditLog.findFirst({
      where:   { workspaceId: membership.workspaceId, action: "legal.baa_requested" },
      orderBy: { createdAt: "desc" },
    })
    if (baaLog) baaState = { status:"pending", requestedAt: baaLog.createdAt }
  } catch { /* ignore */ }

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:0 }}>
      {/* Security settings */}
      <div style={{ padding:24 }}>
        <SecuritySettingsView
          userId={session.user.id}
          workspaceId={membership.workspaceId}
          role={membership.role}
          auditLogs={auditLogs as any}
        />
      </div>

      {/* BAA section */}
      <div style={{ borderTop:"1px solid var(--border)", padding:24, background:"var(--surface)" }}>
        <BAARequestFlow
          workspaceId={membership.workspaceId}
          plan={membership.workspace.plan}
          initialState={baaState}
        />
      </div>
    </div>
  )
}
