// src/app/(app)/settings/custom-fields/page.tsx
import { Metadata } from "next"
import { auth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { db } from "@/lib/db"
import { CustomFieldsView } from "@/components/settings/CustomFieldsView"
export const metadata: Metadata = { title: "Custom fields" }
export default async function CustomFieldsPage() {
  const session = await auth()
  if(!session?.user?.id) redirect("/auth/signin")
  const m = await db.workspaceMember.findFirst({ where:{ userId:session.user.id }, select:{ workspaceId:true, role:true } })
  if(!m) redirect("/onboarding")
  return <CustomFieldsView workspaceId={m.workspaceId} role={m.role} />
}
