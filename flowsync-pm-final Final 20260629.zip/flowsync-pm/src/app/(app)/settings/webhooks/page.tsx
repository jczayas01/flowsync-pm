// src/app/(app)/settings/webhooks/page.tsx
import { Metadata } from "next"
import { auth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { db } from "@/lib/db"
import { WebhooksView } from "@/components/settings/WebhooksView"
export const metadata: Metadata = { title: "Webhooks" }
export default async function WebhooksPage() {
  const session = await auth()
  if(!session?.user?.id) redirect("/auth/signin")
  const m = await db.workspaceMember.findFirst({ where:{ userId:session.user.id }, select:{ workspaceId:true, role:true } })
  if(!m) redirect("/onboarding")
  let webhooks: any[] = []
  try {
    webhooks = await db.$queryRaw`SELECT * FROM webhooks WHERE workspace_id = ${m.workspaceId} ORDER BY created_at DESC`
  } catch { webhooks = [] }
  return <WebhooksView webhooks={webhooks} workspaceId={m.workspaceId} role={m.role} />
}
