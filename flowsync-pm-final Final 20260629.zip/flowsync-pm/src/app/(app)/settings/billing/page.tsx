// src/app/(app)/settings/billing/page.tsx
// Billing settings page — plan overview, upgrade, manage subscription

"use client"

import { useState, useEffect } from "react"

interface Plan {
  id: string; name: string; description: string
  priceMonthlyFormatted: string; priceAnnualFormatted: string
  annualSavings: number; seats: number
  limits: Record<string, boolean | number | string>
}

interface BillingStatus {
  plan: string; status: string; seats: number
  currentPeriodEnd: string | null; trialEnd: string | null
  cancelAtPeriodEnd: boolean; paymentMethod: { brand: string; last4: string } | null
  nextInvoice: { amount: number; date: string } | null
}

export default function BillingPage() {
  const [plans, setPlans]     = useState<Plan[]>([])
  const [billing, setBilling] = useState<BillingStatus | null>(null)
  const [billing2, setBilling2] = useState<"monthly" | "annual">("monthly")
  const [loading, setLoading] = useState(true)
  const [upgrading, setUpgrading] = useState<string | null>(null)

  useEffect(() => {
    fetch("/api/stripe/plans")
      .then(r => r.json())
      .then(d => { setPlans(d.data?.plans || []); setBilling(d.data?.billing || null) })
      .finally(() => setLoading(false))
  }, [])

  const handleUpgrade = async (planId: string) => {
    if (planId === "ENTERPRISE") {
      window.open("mailto:sales@flowsyncpm.com?subject=Enterprise inquiry", "_blank")
      return
    }
    setUpgrading(planId)
    const res  = await fetch("/api/stripe/checkout", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ planId, billing: billing2, seats: 10 }),
    })
    const data = await res.json()
    if (data.data?.url) window.location.href = data.data.url
    setUpgrading(null)
  }

  const handlePortal = async () => {
    const res  = await fetch("/api/stripe/portal", { method: "POST" })
    const data = await res.json()
    if (data.data?.url) window.location.href = data.data.url
  }

  const FEATURE_LABELS: Record<string, string> = {
    projects:       "Active projects",
    methodologies:  "Methodologies",
    aiCopilot:      "AI co-pilot",
    m365:           "M365 integration",
    sso:            "Azure AD SSO",
    whiteLabel:     "White-label branding",
    portfolios:     "Portfolio management",
    apiAccess:      "API access",
    auditLogs:      "Audit logs",
    supportSLA:     "Support",
  }

  if (loading) return (
    <div style={{ padding: 32, color: "#64748B", fontSize: 14 }}>
      Loading billing information…
    </div>
  )

  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: "24px 20px", fontFamily: "Inter, sans-serif" }}>

      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: 20, fontWeight: 600, color: "#0F172A", marginBottom: 4 }}>Billing & subscription</h1>
        <p style={{ fontSize: 13, color: "#64748B" }}>Manage your plan, payment method, and invoices.</p>
      </div>

      {/* Current plan banner */}
      {billing && (
        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 8, padding: "16px 20px", marginBottom: 20, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div style={{ fontSize: 12, color: "#64748B", marginBottom: 4 }}>Current plan</div>
            <div style={{ fontSize: 16, fontWeight: 600, color: "#0F172A" }}>{billing.plan}</div>
            <div style={{ fontSize: 12, color: "#64748B", marginTop: 3 }}>
              {billing.status === "trialing" && billing.trialEnd
                ? `Trial ends ${new Date(billing.trialEnd).toDateString()}`
                : billing.status === "active" && billing.currentPeriodEnd
                ? `Renews ${new Date(billing.currentPeriodEnd).toDateString()}`
                : billing.status === "free" ? "Free plan — no payment required"
                : billing.status}
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {billing.paymentMethod && (
              <div style={{ fontSize: 12, color: "#475569", background: "#F8FAFC", border: "1px solid #E2E8F0", borderRadius: 6, padding: "6px 12px" }}>
                {billing.paymentMethod.brand.toUpperCase()} ···· {billing.paymentMethod.last4}
              </div>
            )}
            {billing.status !== "free" && (
              <button onClick={handlePortal}
                style={{ padding: "7px 14px", border: "1px solid #E2E8F0", borderRadius: 6, background: "#fff", fontSize: 12, fontWeight: 500, cursor: "pointer", fontFamily: "Inter, sans-serif" }}>
                Manage billing →
              </button>
            )}
          </div>
        </div>
      )}

      {/* Billing cycle toggle */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
        <span style={{ fontSize: 13, color: "#64748B" }}>Billing cycle:</span>
        <div style={{ display: "flex", border: "1px solid #E2E8F0", borderRadius: 6, overflow: "hidden" }}>
          {(["monthly","annual"] as const).map(cycle => (
            <button key={cycle} onClick={() => setBilling2(cycle)}
              style={{ padding: "6px 14px", border: "none", fontFamily: "Inter, sans-serif", fontSize: 12, fontWeight: 500, cursor: "pointer",
                background: billing2 === cycle ? "#1B6CA8" : "#fff",
                color:      billing2 === cycle ? "#fff" : "#64748B" }}>
              {cycle === "monthly" ? "Monthly" : "Annual (save 17%)"}
            </button>
          ))}
        </div>
      </div>

      {/* Plan grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14, marginBottom: 28 }}>
        {plans.map(plan => {
          const isCurrent = billing?.plan === plan.id
          const price     = billing2 === "annual" ? plan.priceAnnualFormatted : plan.priceMonthlyFormatted

          return (
            <div key={plan.id}
              style={{ background: "#fff", border: `${isCurrent ? "2px solid #1B6CA8" : "1px solid #E2E8F0"}`, borderRadius: 10, padding: "20px 18px", display: "flex", flexDirection: "column", position: "relative" }}>

              {isCurrent && (
                <div style={{ position: "absolute", top: -11, left: "50%", transform: "translateX(-50%)", background: "#1B6CA8", color: "#fff", fontSize: 10, fontWeight: 700, padding: "3px 12px", borderRadius: 10, whiteSpace: "nowrap" }}>
                  Current plan
                </div>
              )}

              <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: "#64748B", marginBottom: 6 }}>{plan.name}</div>
              <div style={{ fontSize: 28, fontWeight: 700, color: "#0F172A", marginBottom: 2 }}>{price}</div>
              <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 14 }}>
                {billing2 === "annual" && plan.annualSavings > 0 ? `Save ${plan.annualSavings}% vs monthly` : plan.priceMonthly === 0 ? "no credit card needed" : "per month"}
              </div>
              <div style={{ fontSize: 12, color: "#64748B", marginBottom: 16, flex: 1 }}>{plan.description}</div>

              <div style={{ marginBottom: 16 }}>
                {Object.entries(FEATURE_LABELS).map(([key, label]) => {
                  const val = plan.limits[key]
                  const display = val === true ? "✓" : val === false ? "—" : val === -1 ? "∞" : String(val)
                  const positive = val !== false && val !== 0
                  return (
                    <div key={key} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", borderBottom: "1px solid #F1F5F9", fontSize: 11 }}>
                      <span style={{ color: "#64748B" }}>{label}</span>
                      <span style={{ fontWeight: 600, color: positive ? (val === true ? "#059669" : "#0F172A") : "#94A3B8" }}>{display}</span>
                    </div>
                  )
                })}
              </div>

              <button
                onClick={() => !isCurrent && handleUpgrade(plan.id)}
                disabled={isCurrent || upgrading === plan.id}
                style={{
                  width: "100%", padding: "9px", borderRadius: 6, fontSize: 12, fontWeight: 500,
                  cursor: isCurrent ? "default" : "pointer", fontFamily: "Inter, sans-serif", border: "none",
                  background: isCurrent ? "#F1F5F9" : plan.id === "ENTERPRISE" ? "#0D1B2A" : "#1B6CA8",
                  color: isCurrent ? "#64748B" : "#fff",
                  opacity: upgrading && upgrading !== plan.id ? 0.6 : 1,
                }}>
                {upgrading === plan.id ? "Redirecting…"
                  : isCurrent ? "Current plan"
                  : plan.id === "ENTERPRISE" ? "Contact sales"
                  : plan.id === "FREE" ? "Downgrade"
                  : "Upgrade"}
              </button>
            </div>
          )
        })}
      </div>

      {/* Next invoice */}
      {billing?.nextInvoice && (
        <div style={{ background: "#FFFBEB", border: "1px solid #FDE68A", borderRadius: 8, padding: "12px 16px", fontSize: 13, color: "#92400E" }}>
          Next invoice: <strong>${(billing.nextInvoice.amount / 100).toFixed(2)}</strong> due {new Date(billing.nextInvoice.date).toDateString()}
        </div>
      )}

    </div>
  )
}
