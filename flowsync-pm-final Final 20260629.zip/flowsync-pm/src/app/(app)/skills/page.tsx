// src/app/(app)/skills/page.tsx
import { Metadata } from "next"
import { auth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { db } from "@/lib/db"
import { SkillsView } from "@/components/resources/SkillsView"
export const metadata: Metadata = { title: "Skill directory" }
export default async function SkillsPage() {
  const session = await auth()
  if(!session?.user?.id) redirect("/auth/signin")
  const m = await db.workspaceMember.findFirst({ where:{ userId:session.user.id }, select:{ workspaceId:true, role:true } })
  if(!m) redirect("/onboarding")
  const members = await db.workspaceMember.findMany({
    where:{ workspaceId:m.workspaceId },
    include:{ user:{ select:{ id:true, name:true, email:true, avatarUrl:true } } }
  })
  return <SkillsView members={members as any} workspaceId={m.workspaceId} />
}
