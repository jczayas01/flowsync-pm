// src/app/(app)/resources/page.tsx
import { Metadata } from 'next'
import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { db } from '@/lib/db'
import { ResourcesView } from '@/components/resources/ResourcesView'

export const metadata: Metadata = { title: 'Resource management' }

export default async function ResourcesPage() {
  const session = await auth()
  if (!session?.user?.id) redirect('/auth/signin')

  const membership = await db.workspaceMember.findFirst({
    where:  { userId: session.user.id },
    select: { workspaceId:true, role:true },
  })
  if (!membership) redirect('/onboarding')

  const [members, projects, timeEntries] = await Promise.all([
    db.workspaceMember.findMany({
      where:   { workspaceId: membership.workspaceId },
      include: { user: { select:{ id:true, name:true, email:true, avatarUrl:true } } },
    }),
    db.projectMember.findMany({
      where:   { project: { workspaceId: membership.workspaceId, status:'ACTIVE' } },
      include: {
        project: { select:{ id:true, code:true, name:true, color:true } },
        user:    { select:{ id:true, name:true } },
      },
    }),
    db.timeEntry.findMany({
      where: {
        workspaceId: membership.workspaceId,
        date: { gte: new Date(Date.now() - 56*86400000) },
      },
      select: { userId:true, projectId:true, hours:true, date:true, isBillable:true },
    }),
  ])

  return (
    <ResourcesView
      members={members as any}
      projectAssignments={projects as any}
      timeEntries={timeEntries as any}
      workspaceId={membership.workspaceId}
    />
  )
}
