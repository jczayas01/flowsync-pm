// src/app/(app)/goals/page.tsx
import { Metadata } from "next"
import { auth } from "@/lib/auth"
import { redirect } from "next/navigation"
import { db } from "@/lib/db"
import { GoalsView } from "@/components/goals/GoalsView"

export const metadata: Metadata = { title: "Goals & OKRs" }

export default async function GoalsPage() {
  const session = await auth()
  if (!session?.user?.id) redirect("/auth/signin")

  const membership = await db.workspaceMember.findFirst({
    where:  { userId: session.user.id },
    select: { workspaceId: true, role: true },
  })
  if (!membership) redirect("/onboarding")

  // Try to fetch from DB — table may not exist yet
  let goals: any[] = []
  try {
    goals = await db.$queryRaw`
      SELECT g.*,
        json_agg(json_build_object(
          'id', kr.id, 'title', kr.title,
          'progress', kr.progress, 'target', kr.target,
          'current', kr.current_value, 'unit', kr.unit
        )) FILTER (WHERE kr.id IS NOT NULL) as "keyResults"
      FROM goals g
      LEFT JOIN key_results kr ON kr.goal_id = g.id
      WHERE g.workspace_id = ${membership.workspaceId}
      GROUP BY g.id
      ORDER BY g.created_at DESC
    `
  } catch {
    // Goals schema not yet migrated — GoalsView shows sample data
    goals = []
  }

  return (
    <GoalsView
      goals={goals}
      workspaceId={membership.workspaceId}
      userRole={membership.role}
    />
  )
}
