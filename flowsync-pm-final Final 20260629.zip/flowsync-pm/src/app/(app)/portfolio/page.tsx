// src/app/(app)/portfolio/page.tsx
import { Metadata } from 'next'
import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { db } from '@/lib/db'
import { PortfolioView } from '@/components/portfolio/PortfolioView'

export const metadata: Metadata = { title: 'Portfolio' }

export default async function PortfolioPage() {
  const session = await auth()
  if (!session?.user?.id) redirect('/auth/signin')

  const membership = await db.workspaceMember.findFirst({
    where:  { userId: session.user.id },
    select: { workspaceId:true, role:true },
  })
  if (!membership) redirect('/onboarding')

  const portfolios = await db.portfolio.findMany({
    where: { workspaceId: membership.workspaceId },
    include: {
      owner: { select:{ id:true, name:true, avatarUrl:true } },
      programs: {
        include: {
          manager: { select:{ id:true, name:true, avatarUrl:true } },
          projects: {
            select: {
              id:true, code:true, name:true, health:true, status:true,
              percentComplete:true, budgetTotal:true, budgetSpent:true,
              endDate:true, methodology:true,
              members: {
                where: { role:'PM' as any }, take:1,
                include: { user: { select:{ name:true, avatarUrl:true } } },
              },
            },
          },
        },
      },
    },
    orderBy: { createdAt:'asc' },
  })

  // Unassigned projects
  const unassigned = await db.project.findMany({
    where: {
      workspaceId: membership.workspaceId,
      programId:   null,
      status:      { in:['ACTIVE','ON_HOLD','DRAFT'] },
    },
    select: {
      id:true, code:true, name:true, health:true, status:true,
      percentComplete:true, budgetTotal:true, budgetSpent:true, endDate:true,
    },
    orderBy: { createdAt:'desc' },
  })

  return (
    <PortfolioView
      portfolios={portfolios as any}
      unassigned={unassigned as any}
      workspaceId={membership.workspaceId}
      userRole={membership.role}
    />
  )
}
