// src/app/(app)/projects/[projectId]/docs/page.tsx
import { auth } from "@/lib/auth"
import { redirect, notFound } from "next/navigation"
import { db } from "@/lib/db"
import { DocumentEditor } from "@/components/documents/DocumentEditor"

export async function generateMetadata({ params }:{ params:{ projectId:string } }) {
  const p = await db.project.findUnique({ where:{ id:params.projectId }, select:{ name:true, code:true } })
  return { title: p ? `${p.code} Docs` : "Docs" }
}

export default async function ProjectDocsPage({ params }:{ params:{ projectId:string } }) {
  const session = await auth()
  if(!session?.user?.id) redirect("/auth/signin")

  const membership = await db.workspaceMember.findFirst({
    where:{ userId:session.user.id }, select:{ workspaceId:true, role:true }
  })
  if(!membership) redirect("/onboarding")

  // Fetch existing doc blocks if any
  let blocks: any[] | undefined
  try {
    const doc = await db.$queryRaw<any[]>`
      SELECT content FROM project_documents WHERE project_id = ${params.projectId} LIMIT 1
    `
    if(doc[0]?.content) blocks = JSON.parse(doc[0].content)
  } catch { /* table may not exist yet */ }

  return (
    <DocumentEditor
      projectId={params.projectId}
      workspaceId={membership.workspaceId}
      initialBlocks={blocks}
    />
  )
}
