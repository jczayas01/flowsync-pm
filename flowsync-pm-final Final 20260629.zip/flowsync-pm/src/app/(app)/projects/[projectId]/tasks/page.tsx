// src/app/(app)/projects/[projectId]/tasks/page.tsx
import { db } from '@/lib/db'
import { ProjectTasksTab } from '@/components/projects/tabs/ProjectTasksTab'

export default async function ProjectTasksPage({
  params,
  searchParams,
}: {
  params: { projectId: string }
  searchParams: { status?: string; assignee?: string; priority?: string; phase?: string }
}) {
  const where: any = {
    projectId: params.projectId,
    ...(searchParams.status   && { status:   searchParams.status }),
    ...(searchParams.priority && { priority: searchParams.priority }),
    ...(searchParams.phase    && { phaseId:  searchParams.phase }),
    ...(searchParams.assignee && {
      assignees: { some: { userId: searchParams.assignee } },
    }),
  }

  const [tasks, phases, members] = await Promise.all([
    db.task.findMany({
      where,
      orderBy: [{ priority:'asc' }, { dueDate:'asc' }],
      include: {
        assignees: { include: { user: { select: { id:true, name:true, avatarUrl:true } } } },
        phase:     { select: { id:true, name:true } },
        _count:    { select: { comments:true, attachments:true } },
      },
    }),
    db.phase.findMany({
      where:   { projectId: params.projectId },
      orderBy: { order:'asc' },
      select:  { id:true, name:true, status:true },
    }),
    db.projectMember.findMany({
      where:   { projectId: params.projectId },
      include: { user: { select: { id:true, name:true, avatarUrl:true } } },
    }),
  ])

  return (
    <ProjectTasksTab
      projectId={params.projectId}
      tasks={tasks as any}
      phases={phases}
      members={members as any}
      filters={searchParams}
    />
  )
}
