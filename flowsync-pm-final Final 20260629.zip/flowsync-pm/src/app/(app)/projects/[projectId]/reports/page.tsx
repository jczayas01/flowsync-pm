// src/app/(app)/projects/[projectId]/reports/page.tsx
import { db } from '@/lib/db'
import { ProjectReportsTab } from '@/components/projects/tabs/ProjectReportsTab'

export default async function ProjectReportsPage({ params }: { params: { projectId: string } }) {
  const reports = await db.statusUpdate.findMany({
    where:   { projectId: params.projectId },
    orderBy: { createdAt:'desc' },
    include: { createdBy: { select:{ id:true, name:true, avatarUrl:true } } },
    take: 20,
  })

  return <ProjectReportsTab projectId={params.projectId} reports={reports as any} />
}
