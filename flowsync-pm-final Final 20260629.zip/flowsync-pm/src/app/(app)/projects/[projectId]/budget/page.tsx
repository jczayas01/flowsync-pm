// src/app/(app)/projects/[projectId]/budget/page.tsx
import { db } from '@/lib/db'
import { ProjectBudgetTab } from '@/components/projects/tabs/ProjectBudgetTab'

export default async function ProjectBudgetPage({ params }: { params: { projectId: string } }) {
  const [project, budgetItems, timeEntries] = await Promise.all([
    db.project.findUnique({
      where:  { id: params.projectId },
      select: { budgetTotal:true, budgetSpent:true, currency:true, startDate:true, endDate:true },
    }),
    db.budgetItem.findMany({
      where:   { projectId: params.projectId },
      orderBy: { createdAt:'asc' },
    }),
    db.timeEntry.findMany({
      where:   { projectId: params.projectId, isBillable: true },
      orderBy: { date:'desc' },
      include: { user: { select:{ id:true, name:true } } },
    }),
  ])

  return (
    <ProjectBudgetTab
      projectId={params.projectId}
      project={project as any}
      budgetItems={budgetItems as any}
      timeEntries={timeEntries as any}
    />
  )
}
