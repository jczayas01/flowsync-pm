// src/app/(app)/projects/[projectId]/page.tsx — Dashboard tab
import { notFound } from 'next/navigation'
import { db } from '@/lib/db'
import { ProjectDashboardTab } from '@/components/projects/tabs/ProjectDashboardTab'

export default async function ProjectDashboardPage({ params }: { params: { projectId: string } }) {
  const [tasks, risks, milestones, budget] = await Promise.all([
    db.task.findMany({
      where:   { projectId: params.projectId },
      orderBy: { updatedAt:'desc' },
      take: 20,
      include: { assignees: { include: { user: { select:{ id:true, name:true, avatarUrl:true } } } } },
    }),
    db.risk.findMany({
      where:   { projectId: params.projectId, status: { in:['OPEN','TRIGGERED'] } },
      orderBy: { score:'desc' },
      take: 5,
    }),
    db.milestone.findMany({
      where:   { projectId: params.projectId, status: { in:['UPCOMING','AT_RISK'] } },
      orderBy: { dueDate:'asc' },
      take: 5,
    }),
    db.budgetItem.findMany({
      where:   { projectId: params.projectId },
      orderBy: { createdAt:'asc' },
    }),
  ])

  return (
    <ProjectDashboardTab
      projectId={params.projectId}
      tasks={tasks as any}
      risks={risks as any}
      milestones={milestones as any}
      budgetItems={budget as any}
    />
  )
}
