// src/app/(app)/projects/[projectId]/risks/page.tsx
import { db } from '@/lib/db'
import { ProjectRisksTab } from '@/components/projects/tabs/ProjectRisksTab'

export default async function ProjectRisksPage({ params }: { params: { projectId: string } }) {
  const [risks, changes] = await Promise.all([
    db.risk.findMany({
      where:   { projectId: params.projectId },
      orderBy: [{ score:'desc' }, { createdAt:'desc' }],
      include: { owner: { select:{ id:true, name:true, avatarUrl:true } } },
    }),
    db.changeRequest.findMany({
      where:   { projectId: params.projectId },
      orderBy: { createdAt:'desc' },
      include: { createdBy: { select:{ id:true, name:true } } },
    }),
  ])

  return (
    <ProjectRisksTab
      projectId={params.projectId}
      risks={risks as any}
      changes={changes as any}
    />
  )
}
