// src/app/(app)/projects/[projectId]/gantt/page.tsx
import { db } from '@/lib/db'
import { ProjectGanttTab } from '@/components/projects/tabs/ProjectGanttTab'

export default async function ProjectGanttPage({ params }: { params: { projectId: string } }) {
  const [tasks, phases, milestones, baselines] = await Promise.all([
    db.task.findMany({
      where:   { projectId: params.projectId },
      orderBy: [{ phaseId:'asc' }, { startDate:'asc' }],
      include: {
        phase:     { select: { id:true, name:true, order:true } },
        assignees: { include: { user: { select:{ id:true, name:true, avatarUrl:true } } } },
        dependencies: { select: { dependsOnId:true, type:true } },
      },
    }),
    db.phase.findMany({
      where:   { projectId: params.projectId },
      orderBy: { order:'asc' },
    }),
    db.milestone.findMany({
      where:   { projectId: params.projectId },
      orderBy: { dueDate:'asc' },
    }),
    db.baseline.findMany({
      where:   { projectId: params.projectId },
      orderBy: { createdAt:'desc' },
      take: 3,
    }),
  ])

  return (
    <ProjectGanttTab
      projectId={params.projectId}
      tasks={tasks as any}
      phases={phases as any}
      milestones={milestones as any}
      baselines={baselines as any}
    />
  )
}
