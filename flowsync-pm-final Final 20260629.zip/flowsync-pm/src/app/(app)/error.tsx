// src/app/(app)/error.tsx — app-level error boundary (inside layout)
"use client"
import { useEffect } from 'react'
export default function AppError({
  error, reset,
}: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error('[AppError]', error) }, [error])
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center',
      flex:1, padding:24, fontFamily:'var(--font)' }}>
      <div style={{ textAlign:'center', maxWidth:400 }}>
        <div style={{ fontSize:48, marginBottom:12 }}>⚠️</div>
        <h2 style={{ fontSize:18, fontWeight:600, color:'var(--text)', marginBottom:6 }}>
          Something went wrong
        </h2>
        <p style={{ fontSize:13, color:'var(--text-3)', marginBottom:20, lineHeight:1.6 }}>
          {error.message || 'An unexpected error occurred loading this page.'}
        </p>
        <button onClick={reset}
          style={{ padding:'9px 20px', background:'var(--steel)', color:'#fff', border:'none',
            borderRadius:'var(--radius)', fontSize:13, fontWeight:500, cursor:'pointer',
            fontFamily:'var(--font)' }}>
          Try again
        </button>
      </div>
    </div>
  )
}
