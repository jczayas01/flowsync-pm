// src/app/(legal)/cookies/page.tsx
import { Metadata } from "next"
import Link from "next/link"
import { LegalFooter } from "@/components/legal/LegalFooter"

export const metadata: Metadata = {
  title: "Cookie Policy — FlowSync PM",
  description: "FlowSync PM Cookie Policy",
}

export default function CookiesPage() {
  return (
    <div style={{minHeight:"100vh",background:"#F8FAFC",fontFamily:"var(--font)"}}>
      {/* Nav bar */}
      <nav style={{background:"var(--navy,#0D1B2A)",padding:"0 24px",height:56,
        display:"flex",alignItems:"center",justifyContent:"space-between",
        borderBottom:"1px solid rgba(255,255,255,.06)",position:"sticky",top:0,zIndex:100}}>
        <Link href="/" style={{display:"flex",alignItems:"center",gap:8,textDecoration:"none"}}>
          <div style={{width:26,height:26,background:"var(--steel,#1B6CA8)",borderRadius:6,
            position:"relative",flexShrink:0}}>
            <div style={{position:"absolute",width:13,height:2.5,background:"#fff",top:7,left:6,borderRadius:2}}/>
            <div style={{position:"absolute",width:8,height:2.5,background:"var(--amber,#F59E0B)",top:12,left:6,borderRadius:2}}/>
          </div>
          <span style={{fontWeight:700,fontSize:14,color:"#fff"}}>
            FlowSync <span style={{color:"var(--amber,#F59E0B)"}}>PM</span>
          </span>
        </Link>
        <div style={{display:"flex",gap:16,alignItems:"center"}}>
          {% if slug == "terms" %}
          {/* active */}
          {% endif %}
          <Link href="/auth/signin"
            style={{fontSize:12,color:"rgba(255,255,255,.5)",textDecoration:"none"}}>
            Sign in
          </Link>
          <Link href="/auth/signup"
            style={{fontSize:12,fontWeight:600,padding:"6px 14px",background:"var(--amber,#F59E0B)",
              color:"var(--navy,#0D1B2A)",borderRadius:6,textDecoration:"none"}}>
            Get started
          </Link>
        </div>
      </nav>

      <div style={{maxWidth:820,margin:"0 auto",padding:"48px 24px 80px"}}>
        {/* Header */}
        <div style={{marginBottom:40,paddingBottom:24,borderBottom:"1px solid var(--border)"}}>
          <div style={{fontSize:11,fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",
            color:"var(--steel)",marginBottom:10}}>
            Legal
          </div>
          <h1 style={{fontSize:32,fontWeight:700,color:"var(--text)",marginBottom:8,
            letterSpacing:"-.02em"}}>
            Cookie Policy
          </h1>
          <p style={{fontSize:13,color:"var(--text-3)"}}>
            Last updated: June 28, 2026
          </p>
        </div>

        {/* Legal nav */}
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:36}}>
          {[
            ["/terms","Terms of Service"],
            ["/privacy","Privacy Policy"],
            ["/cookies","Cookie Policy"],
            ["/security","Security"],
            ["/acceptable-use","Acceptable Use"],
            ["/refund","Refund Policy"],
          ].map(([href,label]) => (
            <Link key={href} href={href}
              style={{padding:"5px 12px",borderRadius:20,fontSize:12,fontWeight:500,
                textDecoration:"none",border:"1px solid var(--border)",
                background: href === "/cookies" ? "var(--steel)" : "#fff",
                color: href === "/cookies" ? "#fff" : "var(--text-3)"}}>
              {label}
            </Link>
          ))}
        </div>

        {/* Content */}
        <div>
          
          {/* What Are Cookies? */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              1. What Are Cookies?
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Cookies are small text files placed on your device when you visit a website. They help keep you signed in, remember your preferences, and help us understand how the platform is used.
            </p>
          </div>
          {/* Strictly Necessary Cookies */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              2. Strictly Necessary Cookies
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              These cannot be disabled — the Service requires them to function. They include your session token (next-auth.session-token), CSRF protection tokens, and load balancing cookies. No consent is required for these.
            </p>
          </div>
          {/* Functional Cookies */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              3. Functional Cookies
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              These remember your settings: UI preferences (sidebar state, theme), workspace selection, and onboarding progress. You can disable these but some features may not work as expected.
            </p>
          </div>
          {/* Analytics Cookies */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              4. Analytics Cookies
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              These help us improve the platform by tracking feature usage, page views, and session data. All analytics data is aggregated and anonymized. You can opt out by contacting privacy@flowsyncpm.com.
            </p>
          </div>
          {/* Third-Party Cookies */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              5. Third-Party Cookies
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Stripe sets cookies for payment fraud prevention. Google and Microsoft set cookies when you use their OAuth sign-in. These third parties have their own cookie policies.
            </p>
          </div>
          {/* Managing Cookies */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              6. Managing Cookies
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              You can control cookies through your browser settings. Blocking strictly necessary cookies will prevent the Service from functioning. To opt out of analytics cookies, contact privacy@flowsyncpm.com.
            </p>
          </div>
          {/* GDPR Consent */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              7. GDPR Consent
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              For EEA users: we rely on legitimate interests for strictly necessary cookies and your consent for all other categories. You may withdraw consent at any time through the cookie preferences panel (available in the footer).
            </p>
          </div>
          {/* Contact */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              8. Contact
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Questions about cookies: privacy@flowsyncpm.com
            </p>
          </div>
        </div>

        {/* Bottom note */}
        <div style={{marginTop:40,paddingTop:20,borderTop:"1px solid var(--border)",
          fontSize:12,color:"var(--text-3)",lineHeight:1.7}}>
          <strong>Questions about this document?</strong> Contact us at 
          <a href="mailto:legal@flowsyncpm.com"
            style={{color:"var(--steel)",textDecoration:"none"}}>
            legal@flowsyncpm.com
          </a>
          {" "}or write to FlowSync PM, LLC, San Juan, Puerto Rico 00901.
          <br/>
          For an attorney-reviewed copy of any legal document, please contact our legal team directly.
        </div>
      </div>

      <LegalFooter />
    </div>
  )
}
