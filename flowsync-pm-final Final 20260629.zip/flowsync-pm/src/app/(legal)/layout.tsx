// src/app/(legal)/layout.tsx
export default function LegalLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
