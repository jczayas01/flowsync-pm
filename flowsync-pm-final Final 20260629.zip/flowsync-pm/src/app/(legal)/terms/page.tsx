// src/app/(legal)/terms/page.tsx
import { Metadata } from "next"
import Link from "next/link"
import { LegalFooter } from "@/components/legal/LegalFooter"

export const metadata: Metadata = {
  title: "Terms of Service — FlowSync PM",
  description: "FlowSync PM Terms of Service",
}

export default function TermsPage() {
  return (
    <div style={{minHeight:"100vh",background:"#F8FAFC",fontFamily:"var(--font)"}}>
      {/* Nav bar */}
      <nav style={{background:"var(--navy,#0D1B2A)",padding:"0 24px",height:56,
        display:"flex",alignItems:"center",justifyContent:"space-between",
        borderBottom:"1px solid rgba(255,255,255,.06)",position:"sticky",top:0,zIndex:100}}>
        <Link href="/" style={{display:"flex",alignItems:"center",gap:8,textDecoration:"none"}}>
          <div style={{width:26,height:26,background:"var(--steel,#1B6CA8)",borderRadius:6,
            position:"relative",flexShrink:0}}>
            <div style={{position:"absolute",width:13,height:2.5,background:"#fff",top:7,left:6,borderRadius:2}}/>
            <div style={{position:"absolute",width:8,height:2.5,background:"var(--amber,#F59E0B)",top:12,left:6,borderRadius:2}}/>
          </div>
          <span style={{fontWeight:700,fontSize:14,color:"#fff"}}>
            FlowSync <span style={{color:"var(--amber,#F59E0B)"}}>PM</span>
          </span>
        </Link>
        <div style={{display:"flex",gap:16,alignItems:"center"}}>
          {% if slug == "terms" %}
          {/* active */}
          {% endif %}
          <Link href="/auth/signin"
            style={{fontSize:12,color:"rgba(255,255,255,.5)",textDecoration:"none"}}>
            Sign in
          </Link>
          <Link href="/auth/signup"
            style={{fontSize:12,fontWeight:600,padding:"6px 14px",background:"var(--amber,#F59E0B)",
              color:"var(--navy,#0D1B2A)",borderRadius:6,textDecoration:"none"}}>
            Get started
          </Link>
        </div>
      </nav>

      <div style={{maxWidth:820,margin:"0 auto",padding:"48px 24px 80px"}}>
        {/* Header */}
        <div style={{marginBottom:40,paddingBottom:24,borderBottom:"1px solid var(--border)"}}>
          <div style={{fontSize:11,fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",
            color:"var(--steel)",marginBottom:10}}>
            Legal
          </div>
          <h1 style={{fontSize:32,fontWeight:700,color:"var(--text)",marginBottom:8,
            letterSpacing:"-.02em"}}>
            Terms of Service
          </h1>
          <p style={{fontSize:13,color:"var(--text-3)"}}>
            Last updated: June 28, 2026
          </p>
        </div>

        {/* Legal nav */}
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:36}}>
          {[
            ["/terms","Terms of Service"],
            ["/privacy","Privacy Policy"],
            ["/cookies","Cookie Policy"],
            ["/security","Security"],
            ["/acceptable-use","Acceptable Use"],
            ["/refund","Refund Policy"],
          ].map(([href,label]) => (
            <Link key={href} href={href}
              style={{padding:"5px 12px",borderRadius:20,fontSize:12,fontWeight:500,
                textDecoration:"none",border:"1px solid var(--border)",
                background: href === "/terms" ? "var(--steel)" : "#fff",
                color: href === "/terms" ? "#fff" : "var(--text-3)"}}>
              {label}
            </Link>
          ))}
        </div>

        {/* Content */}
        <div>
          
          {/* Agreement to Terms */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              1. Agreement to Terms
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              By accessing or using FlowSync PM, available at flowsyncpm.com, you agree to be bound by these Terms of Service. If you disagree with any part of these Terms, you may not access the Service. If you are using the Service on behalf of an organization, you represent you have authority to bind that organization.
            </p>
          </div>
          {/* Subscription Plans & Payment */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              2. Subscription Plans & Payment
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              The Service is offered under Free, Pro, Consultant, Business, and Enterprise plans. Paid plans are billed monthly or annually in US Dollars. For customers in Puerto Rico, applicable IVU (Impuesto sobre Ventas y Uso) will be applied as required by law. Prices may change with 30 days advance notice.
            </p>
          </div>
          {/* User Content */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              3. User Content
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              You retain ownership of all content you create through the Service. By submitting content, you grant FlowSync PM a limited license to host and display it solely to provide the Service. You are solely responsible for your content and must not submit illegal, harmful, or infringing content.
            </p>
          </div>
          {/* Prohibited Uses */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              4. Prohibited Uses
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              You may not use FlowSync PM to violate any law, attempt unauthorized access, interfere with the Service, scrape data without permission, reverse engineer any part of the platform, resell access without written consent, or impersonate others.
            </p>
          </div>
          {/* HIPAA */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              5. HIPAA
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Covered Entities and Business Associates under HIPAA must execute a Business Associate Agreement (BAA) before storing Protected Health Information (PHI) in FlowSync PM. Contact legal@flowsyncpm.com to request a BAA.
            </p>
          </div>
          {/* Disclaimer of Warranties */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              6. Disclaimer of Warranties
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              THE SERVICE IS PROVIDED 'AS IS' AND 'AS AVAILABLE' WITHOUT WARRANTIES OF ANY KIND. WE DO NOT WARRANT THAT THE SERVICE WILL BE UNINTERRUPTED OR ERROR-FREE.
            </p>
          </div>
          {/* Limitation of Liability */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              7. Limitation of Liability
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              TO THE MAXIMUM EXTENT PERMITTED BY LAW, FLOWSYNC PM SHALL NOT BE LIABLE FOR INDIRECT, INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES. OUR TOTAL LIABILITY SHALL NOT EXCEED THE AMOUNT PAID IN THE PRIOR 12 MONTHS.
            </p>
          </div>
          {/* Governing Law */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              8. Governing Law
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              These Terms are governed by the laws of the Commonwealth of Puerto Rico and applicable US federal law. Disputes shall be resolved in the courts of San Juan, Puerto Rico.
            </p>
          </div>
          {/* Contact */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              9. Contact
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Questions: legal@flowsyncpm.com | FlowSync PM, LLC | San Juan, Puerto Rico 00901
            </p>
          </div>
        </div>

        {/* Bottom note */}
        <div style={{marginTop:40,paddingTop:20,borderTop:"1px solid var(--border)",
          fontSize:12,color:"var(--text-3)",lineHeight:1.7}}>
          <strong>Questions about this document?</strong> Contact us at 
          <a href="mailto:legal@flowsyncpm.com"
            style={{color:"var(--steel)",textDecoration:"none"}}>
            legal@flowsyncpm.com
          </a>
          {" "}or write to FlowSync PM, LLC, San Juan, Puerto Rico 00901.
          <br/>
          For an attorney-reviewed copy of any legal document, please contact our legal team directly.
        </div>
      </div>

      <LegalFooter />
    </div>
  )
}
