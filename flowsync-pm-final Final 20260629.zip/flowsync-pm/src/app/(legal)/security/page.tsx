// src/app/(legal)/security/page.tsx
import { Metadata } from "next"
import Link from "next/link"
import { LegalFooter } from "@/components/legal/LegalFooter"

export const metadata: Metadata = {
  title: "Security Policy — FlowSync PM",
  description: "FlowSync PM Security Policy",
}

export default function SecurityPage() {
  return (
    <div style={{minHeight:"100vh",background:"#F8FAFC",fontFamily:"var(--font)"}}>
      {/* Nav bar */}
      <nav style={{background:"var(--navy,#0D1B2A)",padding:"0 24px",height:56,
        display:"flex",alignItems:"center",justifyContent:"space-between",
        borderBottom:"1px solid rgba(255,255,255,.06)",position:"sticky",top:0,zIndex:100}}>
        <Link href="/" style={{display:"flex",alignItems:"center",gap:8,textDecoration:"none"}}>
          <div style={{width:26,height:26,background:"var(--steel,#1B6CA8)",borderRadius:6,
            position:"relative",flexShrink:0}}>
            <div style={{position:"absolute",width:13,height:2.5,background:"#fff",top:7,left:6,borderRadius:2}}/>
            <div style={{position:"absolute",width:8,height:2.5,background:"var(--amber,#F59E0B)",top:12,left:6,borderRadius:2}}/>
          </div>
          <span style={{fontWeight:700,fontSize:14,color:"#fff"}}>
            FlowSync <span style={{color:"var(--amber,#F59E0B)"}}>PM</span>
          </span>
        </Link>
        <div style={{display:"flex",gap:16,alignItems:"center"}}>
          {% if slug == "terms" %}
          {/* active */}
          {% endif %}
          <Link href="/auth/signin"
            style={{fontSize:12,color:"rgba(255,255,255,.5)",textDecoration:"none"}}>
            Sign in
          </Link>
          <Link href="/auth/signup"
            style={{fontSize:12,fontWeight:600,padding:"6px 14px",background:"var(--amber,#F59E0B)",
              color:"var(--navy,#0D1B2A)",borderRadius:6,textDecoration:"none"}}>
            Get started
          </Link>
        </div>
      </nav>

      <div style={{maxWidth:820,margin:"0 auto",padding:"48px 24px 80px"}}>
        {/* Header */}
        <div style={{marginBottom:40,paddingBottom:24,borderBottom:"1px solid var(--border)"}}>
          <div style={{fontSize:11,fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",
            color:"var(--steel)",marginBottom:10}}>
            Legal
          </div>
          <h1 style={{fontSize:32,fontWeight:700,color:"var(--text)",marginBottom:8,
            letterSpacing:"-.02em"}}>
            Security Policy
          </h1>
          <p style={{fontSize:13,color:"var(--text-3)"}}>
            Last updated: June 28, 2026 · SOC 2 · HIPAA · GDPR
          </p>
        </div>

        {/* Legal nav */}
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:36}}>
          {[
            ["/terms","Terms of Service"],
            ["/privacy","Privacy Policy"],
            ["/cookies","Cookie Policy"],
            ["/security","Security"],
            ["/acceptable-use","Acceptable Use"],
            ["/refund","Refund Policy"],
          ].map(([href,label]) => (
            <Link key={href} href={href}
              style={{padding:"5px 12px",borderRadius:20,fontSize:12,fontWeight:500,
                textDecoration:"none",border:"1px solid var(--border)",
                background: href === "/security" ? "var(--steel)" : "#fff",
                color: href === "/security" ? "#fff" : "var(--text-3)"}}>
              {label}
            </Link>
          ))}
        </div>

        {/* Content */}
        <div>
          
          {/* Infrastructure */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              1. Infrastructure
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              FlowSync PM is hosted on Vercel (SOC 2 Type II certified) with PostgreSQL on Supabase (US East region). All infrastructure uses encryption at rest (AES-256) and in transit (TLS 1.3). We enforce HTTPS across all endpoints with HSTS headers.
            </p>
          </div>
          {/* Authentication & Access Control */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              2. Authentication & Access Control
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              We offer email/password, Google OAuth, Microsoft OAuth, TOTP 2FA, Azure AD SSO (SAML 2.0), and SCIM 2.0 provisioning. Our role-based access control (RBAC) uses 8 roles and 67 permissions with a deny-by-default model. Sessions expire after 30 days of inactivity.
            </p>
          </div>
          {/* Data Encryption */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              3. Data Encryption
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Passwords are hashed with bcrypt (12+ rounds). 2FA secrets are encrypted with AES-256-GCM. API keys are stored as bcrypt hashes. All data in transit uses TLS 1.3. All data at rest uses AES-256.
            </p>
          </div>
          {/* HIPAA Safeguards */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              4. HIPAA Safeguards
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              We implement all three HIPAA Security Rule safeguard categories: Administrative (designated Security Officer, workforce training, risk assessments), Physical (SOC 2 certified data centers, no portable PHI storage), and Technical (unique user IDs, audit controls per §164.312(b), transmission security per §164.312(e)(1)).
            </p>
          </div>
          {/* Audit Logging */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              5. Audit Logging
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Every action in FlowSync PM is recorded in an immutable audit log capturing 47 event types. Logs are retained for a minimum of 7 years and are available for HIPAA compliance reviews.
            </p>
          </div>
          {/* Incident Response */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              6. Incident Response
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              We will notify you within 72 hours of a confirmed breach (GDPR requirement). For HIPAA-covered PHI, we follow the HIPAA Breach Notification Rule (60-day notification). Contact security@flowsyncpm.com for security concerns.
            </p>
          </div>
          {/* Vulnerability Disclosure */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              7. Vulnerability Disclosure
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              If you discover a security vulnerability, please report it responsibly to security@flowsyncpm.com. We commit to acknowledging receipt within 48 hours and providing a resolution timeline within 7 business days.
            </p>
          </div>
          {/* Your Responsibilities */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              8. Your Responsibilities
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Enable 2FA on your account. Use a strong, unique password. Promptly revoke access for former team members. Report suspicious activity to security@flowsyncpm.com immediately.
            </p>
          </div>
          {/* Contact */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              9. Contact
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Security questions: security@flowsyncpm.com | FlowSync PM, LLC | San Juan, Puerto Rico 00901
            </p>
          </div>
        </div>

        {/* Bottom note */}
        <div style={{marginTop:40,paddingTop:20,borderTop:"1px solid var(--border)",
          fontSize:12,color:"var(--text-3)",lineHeight:1.7}}>
          <strong>Questions about this document?</strong> Contact us at 
          <a href="mailto:legal@flowsyncpm.com"
            style={{color:"var(--steel)",textDecoration:"none"}}>
            legal@flowsyncpm.com
          </a>
          {" "}or write to FlowSync PM, LLC, San Juan, Puerto Rico 00901.
          <br/>
          For an attorney-reviewed copy of any legal document, please contact our legal team directly.
        </div>
      </div>

      <LegalFooter />
    </div>
  )
}
