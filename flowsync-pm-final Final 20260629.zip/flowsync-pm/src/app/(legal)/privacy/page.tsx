// src/app/(legal)/privacy/page.tsx
import { Metadata } from "next"
import Link from "next/link"
import { LegalFooter } from "@/components/legal/LegalFooter"

export const metadata: Metadata = {
  title: "Privacy Policy — FlowSync PM",
  description: "FlowSync PM Privacy Policy",
}

export default function PrivacyPage() {
  return (
    <div style={{minHeight:"100vh",background:"#F8FAFC",fontFamily:"var(--font)"}}>
      {/* Nav bar */}
      <nav style={{background:"var(--navy,#0D1B2A)",padding:"0 24px",height:56,
        display:"flex",alignItems:"center",justifyContent:"space-between",
        borderBottom:"1px solid rgba(255,255,255,.06)",position:"sticky",top:0,zIndex:100}}>
        <Link href="/" style={{display:"flex",alignItems:"center",gap:8,textDecoration:"none"}}>
          <div style={{width:26,height:26,background:"var(--steel,#1B6CA8)",borderRadius:6,
            position:"relative",flexShrink:0}}>
            <div style={{position:"absolute",width:13,height:2.5,background:"#fff",top:7,left:6,borderRadius:2}}/>
            <div style={{position:"absolute",width:8,height:2.5,background:"var(--amber,#F59E0B)",top:12,left:6,borderRadius:2}}/>
          </div>
          <span style={{fontWeight:700,fontSize:14,color:"#fff"}}>
            FlowSync <span style={{color:"var(--amber,#F59E0B)"}}>PM</span>
          </span>
        </Link>
        <div style={{display:"flex",gap:16,alignItems:"center"}}>
          {% if slug == "terms" %}
          {/* active */}
          {% endif %}
          <Link href="/auth/signin"
            style={{fontSize:12,color:"rgba(255,255,255,.5)",textDecoration:"none"}}>
            Sign in
          </Link>
          <Link href="/auth/signup"
            style={{fontSize:12,fontWeight:600,padding:"6px 14px",background:"var(--amber,#F59E0B)",
              color:"var(--navy,#0D1B2A)",borderRadius:6,textDecoration:"none"}}>
            Get started
          </Link>
        </div>
      </nav>

      <div style={{maxWidth:820,margin:"0 auto",padding:"48px 24px 80px"}}>
        {/* Header */}
        <div style={{marginBottom:40,paddingBottom:24,borderBottom:"1px solid var(--border)"}}>
          <div style={{fontSize:11,fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",
            color:"var(--steel)",marginBottom:10}}>
            Legal
          </div>
          <h1 style={{fontSize:32,fontWeight:700,color:"var(--text)",marginBottom:8,
            letterSpacing:"-.02em"}}>
            Privacy Policy
          </h1>
          <p style={{fontSize:13,color:"var(--text-3)"}}>
            Last updated: June 28, 2026 · GDPR · HIPAA · CCPA · Puerto Rico Law No. 81 of 2012
          </p>
        </div>

        {/* Legal nav */}
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:36}}>
          {[
            ["/terms","Terms of Service"],
            ["/privacy","Privacy Policy"],
            ["/cookies","Cookie Policy"],
            ["/security","Security"],
            ["/acceptable-use","Acceptable Use"],
            ["/refund","Refund Policy"],
          ].map(([href,label]) => (
            <Link key={href} href={href}
              style={{padding:"5px 12px",borderRadius:20,fontSize:12,fontWeight:500,
                textDecoration:"none",border:"1px solid var(--border)",
                background: href === "/privacy" ? "var(--steel)" : "#fff",
                color: href === "/privacy" ? "#fff" : "var(--text-3)"}}>
              {label}
            </Link>
          ))}
        </div>

        {/* Content */}
        <div>
          
          {/* Introduction */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              1. Introduction
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              FlowSync PM is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information. This policy complies with GDPR, HIPAA, CCPA, and Puerto Rico Law No. 81 of 2012.
            </p>
          </div>
          {/* Information We Collect */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              2. Information We Collect
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              We collect: account information (name, email, password hash); profile information (job title, organization); payment information processed by Stripe; project data you create; usage data and log files; and information from OAuth providers (Google, Microsoft) when you use them to sign in.
            </p>
          </div>
          {/* How We Use Your Information */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              3. How We Use Your Information
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              We use your data to provide and improve the Service, process payments, send transactional emails, respond to support requests, detect fraud, comply with legal obligations, and generate AI-powered reports using your project data.
            </p>
          </div>
          {/* Legal Bases (GDPR) */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              4. Legal Bases (GDPR)
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              For EEA users: we process your data under contract (providing the Service), legitimate interests (improving the Service, preventing fraud), legal obligation (compliance with law), and consent (marketing communications, which you may withdraw at any time).
            </p>
          </div>
          {/* HIPAA & Protected Health Information */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              5. HIPAA & Protected Health Information
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              If you are a Covered Entity, FlowSync PM acts as a Business Associate. We require an executed BAA before any PHI is stored. We implement all required HIPAA administrative, physical, and technical safeguards.
            </p>
          </div>
          {/* Data Sharing */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              6. Data Sharing
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              We do not sell your personal information. We share data only with: service providers (Supabase, Vercel, Stripe, Resend, Azure) under data processing agreements; law enforcement when required by law; and with your explicit consent.
            </p>
          </div>
          {/* Your Rights */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              7. Your Rights
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              You have the right to access, correct, delete, and port your data. EEA residents have full GDPR rights. California residents have CCPA rights. Puerto Rico residents have rights under Law No. 81 of 2012. Contact privacy@flowsyncpm.com to exercise any right.
            </p>
          </div>
          {/* Data Retention & Security */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              8. Data Retention & Security
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              We retain data while your account is active plus 30 days after termination. We use AES-256 encryption at rest, TLS 1.3 in transit, bcrypt password hashing, and role-based access controls.
            </p>
          </div>
          {/* International Transfers */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              9. International Transfers
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Data is stored in the US (AWS US-East). EEA transfers are protected by Standard Contractual Clauses (SCCs) approved by the European Commission.
            </p>
          </div>
          {/* Contact & DPO */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              10. Contact & DPO
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Privacy questions or to exercise your rights: privacy@flowsyncpm.com | FlowSync PM, LLC | San Juan, Puerto Rico 00901
            </p>
          </div>
        </div>

        {/* Bottom note */}
        <div style={{marginTop:40,paddingTop:20,borderTop:"1px solid var(--border)",
          fontSize:12,color:"var(--text-3)",lineHeight:1.7}}>
          <strong>Questions about this document?</strong> Contact us at 
          <a href="mailto:legal@flowsyncpm.com"
            style={{color:"var(--steel)",textDecoration:"none"}}>
            legal@flowsyncpm.com
          </a>
          {" "}or write to FlowSync PM, LLC, San Juan, Puerto Rico 00901.
          <br/>
          For an attorney-reviewed copy of any legal document, please contact our legal team directly.
        </div>
      </div>

      <LegalFooter />
    </div>
  )
}
