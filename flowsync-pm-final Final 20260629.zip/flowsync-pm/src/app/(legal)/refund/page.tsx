// src/app/(legal)/refund/page.tsx
import { Metadata } from "next"
import Link from "next/link"
import { LegalFooter } from "@/components/legal/LegalFooter"

export const metadata: Metadata = {
  title: "Refund Policy — FlowSync PM",
  description: "FlowSync PM Refund Policy",
}

export default function RefundPage() {
  return (
    <div style={{minHeight:"100vh",background:"#F8FAFC",fontFamily:"var(--font)"}}>
      {/* Nav bar */}
      <nav style={{background:"var(--navy,#0D1B2A)",padding:"0 24px",height:56,
        display:"flex",alignItems:"center",justifyContent:"space-between",
        borderBottom:"1px solid rgba(255,255,255,.06)",position:"sticky",top:0,zIndex:100}}>
        <Link href="/" style={{display:"flex",alignItems:"center",gap:8,textDecoration:"none"}}>
          <div style={{width:26,height:26,background:"var(--steel,#1B6CA8)",borderRadius:6,
            position:"relative",flexShrink:0}}>
            <div style={{position:"absolute",width:13,height:2.5,background:"#fff",top:7,left:6,borderRadius:2}}/>
            <div style={{position:"absolute",width:8,height:2.5,background:"var(--amber,#F59E0B)",top:12,left:6,borderRadius:2}}/>
          </div>
          <span style={{fontWeight:700,fontSize:14,color:"#fff"}}>
            FlowSync <span style={{color:"var(--amber,#F59E0B)"}}>PM</span>
          </span>
        </Link>
        <div style={{display:"flex",gap:16,alignItems:"center"}}>
          {% if slug == "terms" %}
          {/* active */}
          {% endif %}
          <Link href="/auth/signin"
            style={{fontSize:12,color:"rgba(255,255,255,.5)",textDecoration:"none"}}>
            Sign in
          </Link>
          <Link href="/auth/signup"
            style={{fontSize:12,fontWeight:600,padding:"6px 14px",background:"var(--amber,#F59E0B)",
              color:"var(--navy,#0D1B2A)",borderRadius:6,textDecoration:"none"}}>
            Get started
          </Link>
        </div>
      </nav>

      <div style={{maxWidth:820,margin:"0 auto",padding:"48px 24px 80px"}}>
        {/* Header */}
        <div style={{marginBottom:40,paddingBottom:24,borderBottom:"1px solid var(--border)"}}>
          <div style={{fontSize:11,fontWeight:600,letterSpacing:".1em",textTransform:"uppercase",
            color:"var(--steel)",marginBottom:10}}>
            Legal
          </div>
          <h1 style={{fontSize:32,fontWeight:700,color:"var(--text)",marginBottom:8,
            letterSpacing:"-.02em"}}>
            Refund Policy
          </h1>
          <p style={{fontSize:13,color:"var(--text-3)"}}>
            Last updated: June 28, 2026
          </p>
        </div>

        {/* Legal nav */}
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:36}}>
          {[
            ["/terms","Terms of Service"],
            ["/privacy","Privacy Policy"],
            ["/cookies","Cookie Policy"],
            ["/security","Security"],
            ["/acceptable-use","Acceptable Use"],
            ["/refund","Refund Policy"],
          ].map(([href,label]) => (
            <Link key={href} href={href}
              style={{padding:"5px 12px",borderRadius:20,fontSize:12,fontWeight:500,
                textDecoration:"none",border:"1px solid var(--border)",
                background: href === "/refund" ? "var(--steel)" : "#fff",
                color: href === "/refund" ? "#fff" : "var(--text-3)"}}>
              {label}
            </Link>
          ))}
        </div>

        {/* Content */}
        <div>
          
          {/* 30-Day Money-Back Guarantee */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              1. 30-Day Money-Back Guarantee
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              New subscribers are eligible for a full refund if they request cancellation within 30 calendar days of their initial paid subscription. This applies once per customer and does not apply to renewals. To request a refund, email billing@flowsyncpm.com within 30 days.
            </p>
          </div>
          {/* Annual Subscriptions */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              2. Annual Subscriptions
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Annual subscriptions can be cancelled at any time. You retain access until the end of the annual period. After the 30-day guarantee, annual subscribers who cancel within the first 6 months may be eligible for a pro-rata refund at our discretion, provided the account has no Terms violations and has not been previously refunded.
            </p>
          </div>
          {/* Monthly Subscriptions */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              3. Monthly Subscriptions
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Monthly subscriptions are billed in advance. Upon cancellation, access continues through the end of the current billing period. Monthly plans are not eligible for partial-month refunds after the 30-day guarantee period.
            </p>
          </div>
          {/* Non-Refundable Items */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              4. Non-Refundable Items
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Setup fees, add-on purchases, accounts terminated for Terms violations, and Enterprise professional services fees are not eligible for refunds.
            </p>
          </div>
          {/* Puerto Rico IVU Tax */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              5. Puerto Rico IVU Tax
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              IVU (Impuesto sobre Ventas y Uso) collected on transactions is remitted to the Puerto Rico Treasury Department (Hacienda). Refunded amounts include any applicable IVU paid.
            </p>
          </div>
          {/* Service Credits */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              6. Service Credits
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              For significant service outages exceeding 1% monthly downtime (beyond our 99.9% SLA), eligible customers may receive service credits applied to future billing cycles. Credits are non-transferable and have no cash value.
            </p>
          </div>
          {/* Chargebacks */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              7. Chargebacks
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Please contact us before initiating a chargeback. Initiating a chargeback without first contacting us may result in account suspension. We will dispute fraudulent chargebacks.
            </p>
          </div>
          {/* Enterprise Plans */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              8. Enterprise Plans
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Enterprise refund terms are governed by the individual Enterprise Agreement. Where no specific terms exist, this Refund Policy applies.
            </p>
          </div>
          {/* Contact */}
          <div style={{marginBottom:28}}>
            <h2 style={{fontSize:17,fontWeight:600,color:"var(--text)",marginBottom:8,
              paddingBottom:6,borderBottom:"2px solid var(--border)"}}>
              9. Contact
            </h2>
            <p style={{fontSize:14,color:"var(--text-2)",lineHeight:1.8,margin:0}}>
              Refund requests and billing questions: billing@flowsyncpm.com | FlowSync PM, LLC | San Juan, Puerto Rico 00901
            </p>
          </div>
        </div>

        {/* Bottom note */}
        <div style={{marginTop:40,paddingTop:20,borderTop:"1px solid var(--border)",
          fontSize:12,color:"var(--text-3)",lineHeight:1.7}}>
          <strong>Questions about this document?</strong> Contact us at 
          <a href="mailto:legal@flowsyncpm.com"
            style={{color:"var(--steel)",textDecoration:"none"}}>
            legal@flowsyncpm.com
          </a>
          {" "}or write to FlowSync PM, LLC, San Juan, Puerto Rico 00901.
          <br/>
          For an attorney-reviewed copy of any legal document, please contact our legal team directly.
        </div>
      </div>

      <LegalFooter />
    </div>
  )
}
