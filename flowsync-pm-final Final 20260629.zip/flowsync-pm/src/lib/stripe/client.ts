// src/lib/stripe/client.ts
// Stripe client singleton + plan definitions

import Stripe from "stripe"

// Singleton — one Stripe instance across the app
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-04-10",
  typescript:  true,
  appInfo: {
    name:    "FlowSync PM",
    version: "1.0.0",
    url:     "https://flowsyncpm.com",
  },
})

// ─────────────────────────────────────────────
// PLAN DEFINITIONS
// Single source of truth for all plan limits and features.
// These map 1:1 to the Stripe Price IDs in .env
// ─────────────────────────────────────────────

export type PlanId = "FREE" | "PRO" | "CONSULTANT" | "BUSINESS" | "ENTERPRISE"

export interface Plan {
  id:            PlanId
  name:          string
  description:   string
  priceMonthly:  number  // USD cents
  priceAnnual:   number  // USD cents (per month, billed annually)
  stripePriceId: string | null          // monthly
  stripePriceIdAnnual: string | null    // annual
  seats:         number  // -1 = unlimited
  limits: {
    projects:    number  // -1 = unlimited
    methodologies: number
    aiCopilot:   boolean
    m365:        boolean
    sso:         boolean
    whiteLabel:  boolean
    templates:   boolean  // marketplace Phase 2
    portfolios:  boolean
    apiAccess:   boolean
    auditLogs:   boolean
    supportSLA:  string
  }
}

export const PLANS: Record<PlanId, Plan> = {
  FREE: {
    id:           "FREE",
    name:         "Free",
    description:  "For solo PMs exploring the platform",
    priceMonthly: 0,
    priceAnnual:  0,
    stripePriceId:       null,
    stripePriceIdAnnual: null,
    seats:        1,
    limits: {
      projects:      3,
      methodologies: 1,
      aiCopilot:     false,
      m365:          false,
      sso:           false,
      whiteLabel:    false,
      templates:     false,
      portfolios:    false,
      apiAccess:     false,
      auditLogs:     false,
      supportSLA:    "community",
    },
  },

  PRO: {
    id:           "PRO",
    name:         "Pro",
    description:  "For active solo PMs and consultants",
    priceMonthly: 1900,  // $19.00
    priceAnnual:  1583,  // $15.83/mo billed annually = $190/yr
    stripePriceId:       process.env.STRIPE_PRICE_PRO_MONTHLY      || null,
    stripePriceIdAnnual: process.env.STRIPE_PRICE_PRO_ANNUAL       || null,
    seats:        1,
    limits: {
      projects:      -1,
      methodologies:  3,
      aiCopilot:     true,
      m365:          false,
      sso:           false,
      whiteLabel:    false,
      templates:     true,
      portfolios:    false,
      apiAccess:     false,
      auditLogs:     false,
      supportSLA:    "email",
    },
  },

  CONSULTANT: {
    id:           "CONSULTANT",
    name:         "Consultant",
    description:  "One login, multiple client workspaces",
    priceMonthly: 4900,  // $49.00
    priceAnnual:  4083,  // $40.83/mo
    stripePriceId:       process.env.STRIPE_PRICE_CONSULTANT_MONTHLY || null,
    stripePriceIdAnnual: process.env.STRIPE_PRICE_CONSULTANT_ANNUAL  || null,
    seats:        1,  // 1 consultant + client guests
    limits: {
      projects:      -1,
      methodologies:  3,
      aiCopilot:     true,
      m365:          true,
      sso:           false,
      whiteLabel:    true,  // client-branded reports
      templates:     true,
      portfolios:    false,
      apiAccess:     false,
      auditLogs:     true,
      supportSLA:    "priority-email",
    },
  },

  BUSINESS: {
    id:           "BUSINESS",
    name:         "Business",
    description:  "For teams running multiple projects",
    priceMonthly: 7900,  // $79/mo base (up to 10 seats)
    priceAnnual:  6583,  // $65.83/mo
    stripePriceId:       process.env.STRIPE_PRICE_BUSINESS_MONTHLY  || null,
    stripePriceIdAnnual: process.env.STRIPE_PRICE_BUSINESS_ANNUAL   || null,
    seats:        10,
    limits: {
      projects:      -1,
      methodologies:  3,
      aiCopilot:     true,
      m365:          true,
      sso:           true,
      whiteLabel:    true,
      templates:     true,
      portfolios:    true,
      apiAccess:     false,
      auditLogs:     true,
      supportSLA:    "business-hours",
    },
  },

  ENTERPRISE: {
    id:           "ENTERPRISE",
    name:         "Enterprise",
    description:  "For large organizations and PMOs",
    priceMonthly: -1,  // custom pricing
    priceAnnual:  -1,
    stripePriceId:       null,  // handled via Stripe quotes
    stripePriceIdAnnual: null,
    seats:        -1,  // unlimited
    limits: {
      projects:      -1,
      methodologies:  3,
      aiCopilot:     true,
      m365:          true,
      sso:           true,
      whiteLabel:    true,
      templates:     true,
      portfolios:    true,
      apiAccess:     true,
      auditLogs:     true,
      supportSLA:    "24-7-sla",
    },
  },
}

// ── Helpers ──

export function getPlan(planId: PlanId): Plan {
  return PLANS[planId] || PLANS.FREE
}

export function getPlanByStripePrice(priceId: string): Plan | null {
  return Object.values(PLANS).find(
    p => p.stripePriceId === priceId || p.stripePriceIdAnnual === priceId
  ) || null
}

/** Check if a workspace is within its plan limits */
export async function checkPlanLimit(
  workspaceId: string,
  limitKey: keyof Plan["limits"]
): Promise<{ allowed: boolean; current?: number; limit?: number; plan: PlanId }> {
  const { db } = await import("@/lib/db")

  const workspace = await db.workspace.findUnique({
    where:  { id: workspaceId },
    select: { plan: true, seats: true },
  })

  if (!workspace) return { allowed: false, plan: "FREE" }

  const plan  = getPlan(workspace.plan as PlanId)
  const limit = plan.limits[limitKey]

  if (typeof limit === "boolean") {
    return { allowed: limit, plan: workspace.plan as PlanId }
  }

  if (limit === -1) return { allowed: true, plan: workspace.plan as PlanId }

  // Count current usage for numeric limits
  if (limitKey === "projects") {
    const current = await db.project.count({
      where: { workspaceId, status: { notIn: ["ARCHIVED","CANCELLED"] } },
    })
    return { allowed: current < limit, current, limit, plan: workspace.plan as PlanId }
  }

  return { allowed: true, plan: workspace.plan as PlanId }
}

/** Format price for display */
export function formatPrice(cents: number, currency = "usd"): string {
  if (cents === -1) return "Custom"
  if (cents === 0)  return "Free"
  return new Intl.NumberFormat("en-US", {
    style:    "currency",
    currency: currency.toUpperCase(),
    maximumFractionDigits: cents % 100 === 0 ? 0 : 2,
  }).format(cents / 100)
}
