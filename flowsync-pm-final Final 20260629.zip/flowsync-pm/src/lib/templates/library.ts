// src/lib/templates/library.ts
// Built-in template library — installed at workspace creation
// and available in the public marketplace

export interface TemplatePhase {
  name:        string
  description: string
  order:       number
  durationWeeks: number
  tasks:       TemplateTask[]
  milestones?: TemplateMilestone[]
}

export interface TemplateTask {
  title:          string
  description?:   string
  estimatedHours: number
  priority:       "CRITICAL"|"HIGH"|"MEDIUM"|"LOW"
  role:           string   // suggested role for assignee
}

export interface TemplateMilestone {
  name:        string
  weekOffset:  number   // weeks from phase start
}

export interface TemplateRiskCategory {
  name:     string
  examples: string[]
}

export interface TemplateDefinition {
  id:           string
  name:         string
  description:  string
  longDescription: string
  methodology:  "WATERFALL"|"AGILE"|"SCRUM"
  industry:     string
  category:     string
  icon:         string
  color:        string
  estimatedWeeks: number
  teamSize:     string
  difficulty:   "Beginner"|"Intermediate"|"Advanced"
  tags:         string[]
  isPremium:    boolean
  price:        number        // cents, 0 = free
  usageCount:   number
  rating:       number        // 0-5
  ratingCount:  number
  author:       string
  authorOrg?:   string
  phases:       TemplatePhase[]
  riskCategories: TemplateRiskCategory[]
  documentTypes:  string[]
  featured:     boolean
}

export const TEMPLATE_LIBRARY: TemplateDefinition[] = [

  // ─── HEALTHCARE ──────────────────────────────────────
  {
    id: "ehr-implementation",
    name: "EHR System Implementation",
    description: "Full lifecycle for deploying an Electronic Health Records system across a healthcare organization.",
    longDescription: "Covers requirements gathering, HL7/FHIR integration planning, legacy data migration, staff training, and go-live support. Pre-loaded with HIPAA compliance checkpoints and clinical workflow validation gates.",
    methodology: "WATERFALL",
    industry: "Healthcare",
    category: "IT Implementation",
    icon: "🏥",
    color: "#059669",
    estimatedWeeks: 36,
    teamSize: "8–15 people",
    difficulty: "Advanced",
    tags: ["EHR","EMR","HL7","FHIR","HIPAA","Healthcare IT"],
    isPremium: false,
    price: 0,
    usageCount: 847,
    rating: 4.8,
    ratingCount: 124,
    author: "FlowSync PM",
    featured: true,
    phases: [
      { name:"Initiation & Charter", description:"Project charter, stakeholder mapping, governance setup", order:0, durationWeeks:3,
        tasks:[
          {title:"Project charter", estimatedHours:40, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"Stakeholder register", estimatedHours:24, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"HIPAA risk assessment", estimatedHours:32, priority:"CRITICAL", role:"SUPER_USER"},
          {title:"Governance framework", estimatedHours:16, priority:"MEDIUM", role:"ADMIN"},
        ],
        milestones:[{name:"Charter approved", weekOffset:3}]
      },
      { name:"Requirements & Design", description:"Clinical workflow analysis, system requirements, integration architecture", order:1, durationWeeks:8,
        tasks:[
          {title:"Current workflow analysis", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"System requirements specification", estimatedHours:120, priority:"CRITICAL", role:"PROJECT_MANAGER"},
          {title:"HL7 FHIR integration design", estimatedHours:64, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Data migration strategy", estimatedHours:40, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Security architecture review", estimatedHours:32, priority:"CRITICAL", role:"SUPER_USER"},
        ],
        milestones:[{name:"Requirements sign-off", weekOffset:8}]
      },
      { name:"Configuration & Build", description:"System configuration, interface builds, custom development", order:2, durationWeeks:12,
        tasks:[
          {title:"Core EHR configuration", estimatedHours:200, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"HL7 interface development", estimatedHours:160, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Legacy data migration scripts", estimatedHours:120, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Custom report development", estimatedHours:80, priority:"MEDIUM", role:"TEAM_MEMBER"},
          {title:"Security controls implementation", estimatedHours:60, priority:"CRITICAL", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Build complete", weekOffset:12}]
      },
      { name:"Testing & Validation", description:"SIT, UAT, clinical validation, performance testing", order:3, durationWeeks:8,
        tasks:[
          {title:"System integration testing", estimatedHours:160, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"User acceptance testing — clinical", estimatedHours:120, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Performance & load testing", estimatedHours:40, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Security penetration testing", estimatedHours:40, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"HIPAA compliance validation", estimatedHours:32, priority:"CRITICAL", role:"SUPER_USER"},
        ],
        milestones:[{name:"UAT sign-off", weekOffset:8}]
      },
      { name:"Training & Go-Live", description:"Staff training, cutover planning, go-live support", order:4, durationWeeks:5,
        tasks:[
          {title:"Training material development", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Staff training delivery", estimatedHours:120, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Go-live cutover plan", estimatedHours:40, priority:"CRITICAL", role:"PROJECT_MANAGER"},
          {title:"Data migration cutover", estimatedHours:60, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Post go-live support (30 days)", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Go-live", weekOffset:3},{name:"Stabilization complete", weekOffset:5}]
      },
    ],
    riskCategories:[
      {name:"Clinical workflow disruption", examples:["Staff resistance to change","Workflow redesign failures"]},
      {name:"Data migration", examples:["Legacy data quality issues","Migration downtime"]},
      {name:"Integration failures", examples:["HL7 interface errors","Lab system connectivity"]},
      {name:"HIPAA compliance", examples:["PHI exposure during migration","Audit trail gaps"]},
    ],
    documentTypes:["Project Charter","Requirements Specification","HL7 Interface Design","Training Plan","Go-Live Runbook","HIPAA Compliance Checklist"],
  },

  {
    id: "patient-portal",
    name: "Patient Portal Development",
    description: "Agile delivery of a patient-facing web and mobile portal with scheduling, records access, and telehealth.",
    longDescription: "Sprint-based delivery covering patient authentication, appointment scheduling, medical records viewing, prescription refills, and secure messaging. Includes HIPAA-compliant design patterns and accessibility (WCAG 2.1) checkpoints.",
    methodology: "AGILE",
    industry: "Healthcare",
    category: "Product Development",
    icon: "📱",
    color: "#1B6CA8",
    estimatedWeeks: 20,
    teamSize: "5–8 people",
    difficulty: "Intermediate",
    tags: ["Patient Portal","HIPAA","Telehealth","React","Mobile"],
    isPremium: false,
    price: 0,
    usageCount: 412,
    rating: 4.6,
    ratingCount: 68,
    author: "FlowSync PM",
    featured: true,
    phases:[
      {name:"Discovery & Design", description:"UX research, wireframes, technical architecture", order:0, durationWeeks:4,
        tasks:[
          {title:"Patient journey mapping", estimatedHours:32, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"UI/UX wireframes", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Technical architecture", estimatedHours:40, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"HIPAA design review", estimatedHours:16, priority:"CRITICAL", role:"SUPER_USER"},
        ],
        milestones:[{name:"Design approved", weekOffset:4}]
      },
      {name:"Sprint 1–3: Core authentication & records", description:"Patient login, MFA, records viewing", order:1, durationWeeks:6,
        tasks:[
          {title:"Patient authentication (MFA)", estimatedHours:60, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Medical records viewer", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"FHIR API integration", estimatedHours:100, priority:"CRITICAL", role:"TEAM_MEMBER"},
        ]
      },
      {name:"Sprint 4–6: Scheduling & messaging", description:"Appointment booking, secure messaging", order:2, durationWeeks:6,
        tasks:[
          {title:"Appointment scheduling", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Secure messaging", estimatedHours:60, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Prescription refill requests", estimatedHours:40, priority:"MEDIUM", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Beta release", weekOffset:6}]
      },
      {name:"UAT & Launch", description:"User testing, accessibility audit, production launch", order:3, durationWeeks:4,
        tasks:[
          {title:"Patient UAT program", estimatedHours:60, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"WCAG 2.1 accessibility audit", estimatedHours:24, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Performance optimization", estimatedHours:32, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Production deployment", estimatedHours:20, priority:"CRITICAL", role:"PROJECT_MANAGER"},
        ],
        milestones:[{name:"Go-live", weekOffset:4}]
      },
    ],
    riskCategories:[
      {name:"HIPAA compliance", examples:["PHI in logs","Insecure token storage"]},
      {name:"Integration", examples:["EHR API rate limits","FHIR version compatibility"]},
    ],
    documentTypes:["UX Research Report","API Design Spec","HIPAA Compliance Review","UAT Results","Launch Checklist"],
  },

  // ─── IT / INFRASTRUCTURE ────────────────────
  {
    id: "cloud-migration",
    name: "Cloud Migration (AWS / Azure)",
    description: "Enterprise migration from on-premise infrastructure to cloud with zero-downtime cutover.",
    longDescription: "Covers discovery, architecture design, pilot migration, parallel running, and full cutover. Supports AWS, Azure, and hybrid deployments. Includes rollback procedures and business continuity planning at each gate.",
    methodology: "WATERFALL",
    industry: "IT",
    category: "Infrastructure",
    icon: "☁️",
    color: "#0891B2",
    estimatedWeeks: 24,
    teamSize: "6–12 people",
    difficulty: "Advanced",
    tags: ["Cloud","AWS","Azure","Migration","Infrastructure","DevOps"],
    isPremium: true,
    price: 4900,
    usageCount: 623,
    rating: 4.9,
    ratingCount: 89,
    author: "CloudOps Pro",
    authorOrg: "CloudOps Consulting",
    featured: true,
    phases:[
      {name:"Discovery & Assessment", description:"Current state analysis, TCO, migration strategy", order:0, durationWeeks:4,
        tasks:[
          {title:"Infrastructure inventory", estimatedHours:60, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Dependency mapping", estimatedHours:40, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Cloud readiness assessment", estimatedHours:32, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"TCO analysis", estimatedHours:24, priority:"HIGH", role:"PROJECT_MANAGER"},
        ],
        milestones:[{name:"Assessment complete", weekOffset:4}]
      },
      {name:"Architecture & Design", description:"Target architecture, network design, security model", order:1, durationWeeks:5,
        tasks:[
          {title:"Target architecture design", estimatedHours:120, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Network & security design", estimatedHours:80, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"DR / BCP planning", estimatedHours:40, priority:"HIGH", role:"PROJECT_MANAGER"},
        ],
        milestones:[{name:"Architecture approved", weekOffset:5}]
      },
      {name:"Pilot Migration", description:"Migrate 2-3 non-critical workloads, validate approach", order:2, durationWeeks:6,
        tasks:[
          {title:"Pilot workload migration", estimatedHours:160, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Performance benchmarking", estimatedHours:40, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Cost optimization review", estimatedHours:20, priority:"MEDIUM", role:"PROJECT_MANAGER"},
        ],
        milestones:[{name:"Pilot approved", weekOffset:6}]
      },
      {name:"Full Migration", description:"Wave-based migration of all workloads", order:3, durationWeeks:7,
        tasks:[
          {title:"Wave 1: Dev/test environments", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Wave 2: Business applications", estimatedHours:200, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Wave 3: Production databases", estimatedHours:160, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"DNS cutover", estimatedHours:20, priority:"CRITICAL", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Migration complete", weekOffset:7}]
      },
      {name:"Optimization & Closure", description:"Cost optimization, monitoring setup, decommission", order:4, durationWeeks:2,
        tasks:[
          {title:"Cloud cost optimization", estimatedHours:40, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Monitoring & alerting setup", estimatedHours:32, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Old infrastructure decommission", estimatedHours:20, priority:"MEDIUM", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Project closed", weekOffset:2}]
      },
    ],
    riskCategories:[
      {name:"Data loss", examples:["Migration failures","Incomplete backups"]},
      {name:"Downtime", examples:["DNS propagation delays","Dependency failures"]},
      {name:"Cost overrun", examples:["Unexpected egress fees","Over-provisioning"]},
    ],
    documentTypes:["Discovery Report","Target Architecture","Migration Plan","Runbook","DR Plan"],
  },

  {
    id: "software-dev-scrum",
    name: "Software Development (Scrum)",
    description: "Standard Scrum setup for a software development team — backlog, sprints, ceremonies, and definition of done.",
    longDescription: "Pre-configured with a product backlog, sprint board, velocity tracking, and all Scrum ceremonies (standup, planning, review, retro). Includes ready-made epics for common software features.",
    methodology: "SCRUM",
    industry: "IT",
    category: "Product Development",
    icon: "🏃",
    color: "#7C3AED",
    estimatedWeeks: 12,
    teamSize: "4–9 people",
    difficulty: "Beginner",
    tags: ["Scrum","Agile","Software","Sprints","Development"],
    isPremium: false,
    price: 0,
    usageCount: 1842,
    rating: 4.7,
    ratingCount: 312,
    author: "FlowSync PM",
    featured: true,
    phases:[
      {name:"Sprint 0: Setup", description:"Team setup, backlog seeding, definition of done", order:0, durationWeeks:2,
        tasks:[
          {title:"Create product backlog", estimatedHours:16, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"Define DoD (Definition of Done)", estimatedHours:4, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Set up development environment", estimatedHours:20, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Sprint 1 planning", estimatedHours:4, priority:"HIGH", role:"PROJECT_MANAGER"},
        ]
      },
      {name:"Sprint 1", description:"First sprint — core functionality", order:1, durationWeeks:2,
        tasks:[
          {title:"User story: [Replace with your story]", estimatedHours:8, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Code review & PR", estimatedHours:4, priority:"MEDIUM", role:"TEAM_MEMBER"},
          {title:"Sprint review & demo", estimatedHours:2, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Sprint retrospective", estimatedHours:1, priority:"MEDIUM", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Sprint 1 complete", weekOffset:2}]
      },
    ],
    riskCategories:[
      {name:"Scope creep", examples:["Backlog bloat","Undocumented requirements"]},
      {name:"Velocity issues", examples:["Team capacity changes","Unplanned work"]},
    ],
    documentTypes:["Product Backlog","Sprint Plan","Velocity Chart","Retro Notes","Release Notes"],
  },

  // ─── CONSTRUCTION / FACILITIES ──────────────
  {
    id: "construction-project",
    name: "Construction Project Management",
    description: "Full construction lifecycle from design through handover, with contractor management and safety checkpoints.",
    longDescription: "Covers pre-construction planning, design approvals, procurement, construction phases with daily logs, inspections, and punch list management through to certificate of occupancy and client handover.",
    methodology: "WATERFALL",
    industry: "Construction",
    category: "Construction",
    icon: "🏗",
    color: "#EA580C",
    estimatedWeeks: 52,
    teamSize: "10–30 people",
    difficulty: "Advanced",
    tags: ["Construction","Facilities","Architecture","Contractor","Safety"],
    isPremium: true,
    price: 9900,
    usageCount: 234,
    rating: 4.7,
    ratingCount: 41,
    author: "BuildPM Pro",
    featured: false,
    phases:[
      {name:"Pre-Construction", description:"Design, permits, procurement", order:0, durationWeeks:16,
        tasks:[
          {title:"Schematic design review", estimatedHours:40, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"Permit applications", estimatedHours:20, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Contractor bid process", estimatedHours:60, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"Contract execution", estimatedHours:20, priority:"CRITICAL", role:"SUPER_USER"},
        ],
        milestones:[{name:"Permits approved", weekOffset:12},{name:"Contracts signed", weekOffset:16}]
      },
      {name:"Foundation & Structure", description:"Site prep, foundation, structural frame", order:1, durationWeeks:16,
        tasks:[
          {title:"Site preparation & clearing", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Foundation work", estimatedHours:200, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Structural frame", estimatedHours:320, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Structural inspection", estimatedHours:16, priority:"CRITICAL", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Foundation inspection", weekOffset:8},{name:"Frame complete", weekOffset:16}]
      },
      {name:"MEP & Interiors", description:"Mechanical, electrical, plumbing, interior finishes", order:2, durationWeeks:16,
        tasks:[
          {title:"MEP rough-in", estimatedHours:400, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"MEP inspections", estimatedHours:32, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Drywall & finishes", estimatedHours:240, priority:"MEDIUM", role:"TEAM_MEMBER"},
          {title:"Flooring & fixtures", estimatedHours:160, priority:"MEDIUM", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"MEP inspection", weekOffset:8},{name:"Interiors complete", weekOffset:16}]
      },
      {name:"Punch List & Handover", description:"Final inspections, punch list, client walkthrough", order:3, durationWeeks:4,
        tasks:[
          {title:"Punch list walkthrough", estimatedHours:20, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"Punch list completion", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Certificate of Occupancy", estimatedHours:12, priority:"CRITICAL", role:"PROJECT_MANAGER"},
          {title:"Client handover", estimatedHours:8, priority:"HIGH", role:"PROJECT_MANAGER"},
        ],
        milestones:[{name:"Certificate of Occupancy", weekOffset:3},{name:"Client handover", weekOffset:4}]
      },
    ],
    riskCategories:[
      {name:"Weather delays", examples:["Extreme weather halting work"]},
      {name:"Permit delays", examples:["Inspection backlogs","Code compliance issues"]},
      {name:"Contractor issues", examples:["Subcontractor default","Material shortages"]},
      {name:"Safety", examples:["OSHA incidents","Near misses"]},
    ],
    documentTypes:["Construction Schedule","Submittals Log","RFI Log","Daily Reports","Change Order Log","Inspection Reports","Punch List"],
  },

  // ─── COMPLIANCE ─────────────────────────────
  {
    id: "hipaa-compliance",
    name: "HIPAA Compliance Program",
    description: "Implement or audit a HIPAA compliance program — policies, risk analysis, training, and BAA management.",
    longDescription: "Structured program covering the Security Rule, Privacy Rule, and Breach Notification Rule. Includes risk analysis methodology, policy library structure, workforce training rollout, and Business Associate Agreement tracking.",
    methodology: "WATERFALL",
    industry: "Healthcare",
    category: "Compliance",
    icon: "🔒",
    color: "#DC2626",
    estimatedWeeks: 16,
    teamSize: "3–6 people",
    difficulty: "Intermediate",
    tags: ["HIPAA","Compliance","Healthcare","Security","Privacy","PHI"],
    isPremium: false,
    price: 0,
    usageCount: 389,
    rating: 4.8,
    ratingCount: 57,
    author: "FlowSync PM",
    featured: false,
    phases:[
      {name:"Gap Assessment", description:"Current state vs HIPAA requirements", order:0, durationWeeks:3,
        tasks:[
          {title:"Security rule gap analysis", estimatedHours:40, priority:"CRITICAL", role:"PROJECT_MANAGER"},
          {title:"Privacy rule gap analysis", estimatedHours:32, priority:"CRITICAL", role:"PROJECT_MANAGER"},
          {title:"PHI inventory & data flow mapping", estimatedHours:24, priority:"HIGH", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Gap report complete", weekOffset:3}]
      },
      {name:"Risk Analysis & Management", description:"Formal risk analysis, risk management plan", order:1, durationWeeks:4,
        tasks:[
          {title:"Formal risk analysis (Security Rule §164.308)", estimatedHours:60, priority:"CRITICAL", role:"PROJECT_MANAGER"},
          {title:"Risk management plan", estimatedHours:24, priority:"CRITICAL", role:"PROJECT_MANAGER"},
          {title:"Remediation prioritization", estimatedHours:16, priority:"HIGH", role:"SUPER_USER"},
        ],
        milestones:[{name:"Risk analysis approved", weekOffset:4}]
      },
      {name:"Policy & Procedure Development", description:"Draft, review, and approve required policies", order:2, durationWeeks:5,
        tasks:[
          {title:"Security policies (18 required)", estimatedHours:80, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Privacy policies", estimatedHours:40, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Incident response procedures", estimatedHours:24, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"BAA inventory & review", estimatedHours:20, priority:"HIGH", role:"PROJECT_MANAGER"},
        ],
        milestones:[{name:"Policies approved", weekOffset:5}]
      },
      {name:"Training & Implementation", description:"Workforce training, technical safeguards, go-live", order:3, durationWeeks:4,
        tasks:[
          {title:"HIPAA training program", estimatedHours:32, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Workforce training delivery", estimatedHours:40, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Technical safeguards implementation", estimatedHours:60, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Documentation & attestation", estimatedHours:20, priority:"HIGH", role:"PROJECT_MANAGER"},
        ],
        milestones:[{name:"Training complete", weekOffset:3},{name:"Program live", weekOffset:4}]
      },
    ],
    riskCategories:[
      {name:"Documentation gaps", examples:["Missing policies","Unsigned BAAs"]},
      {name:"Technical safeguards", examples:["Unencrypted PHI","Audit log failures"]},
    ],
    documentTypes:["Gap Analysis Report","Risk Analysis","Policy Library","Training Records","BAA Tracker","Audit Report"],
  },

  // ─── PRODUCT DEVELOPMENT ────────────────────
  {
    id: "saas-product-launch",
    name: "SaaS Product Launch",
    description: "From MVP to public launch — product development, beta program, go-to-market, and growth metrics.",
    longDescription: "Scrum-based delivery covering product discovery, MVP development, closed beta, open beta, and public launch. Includes GTM planning, pricing strategy, and post-launch growth tracking sprints.",
    methodology: "SCRUM",
    industry: "Technology",
    category: "Product Launch",
    icon: "🚀",
    color: "#7C3AED",
    estimatedWeeks: 24,
    teamSize: "4–10 people",
    difficulty: "Intermediate",
    tags: ["SaaS","Product","Launch","MVP","Beta","GTM"],
    isPremium: true,
    price: 2900,
    usageCount: 756,
    rating: 4.6,
    ratingCount: 103,
    author: "ProductOps Studio",
    featured: true,
    phases:[
      {name:"Discovery & MVP Definition", description:"Customer discovery, problem validation, MVP scope", order:0, durationWeeks:4,
        tasks:[
          {title:"Customer discovery interviews (20+)", estimatedHours:40, priority:"CRITICAL", role:"PROJECT_MANAGER"},
          {title:"Problem statement & solution hypothesis", estimatedHours:16, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"MVP feature scope", estimatedHours:20, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Technical spike & architecture", estimatedHours:32, priority:"HIGH", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"MVP scope locked", weekOffset:4}]
      },
      {name:"MVP Development (Sprints 1–6)", description:"Core product development, 2-week sprints", order:1, durationWeeks:12,
        tasks:[
          {title:"Sprint 1: Core authentication & onboarding", estimatedHours:80, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Sprint 2–3: Core feature set", estimatedHours:160, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Sprint 4–5: Integrations & billing", estimatedHours:120, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Sprint 6: Polish & performance", estimatedHours:80, priority:"MEDIUM", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"MVP complete", weekOffset:12}]
      },
      {name:"Beta Program", description:"Closed beta, feedback loops, iteration", order:2, durationWeeks:4,
        tasks:[
          {title:"Beta user recruitment (50 users)", estimatedHours:20, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"Beta feedback collection & analysis", estimatedHours:40, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Priority bug fixes & improvements", estimatedHours:80, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Pricing & packaging finalization", estimatedHours:16, priority:"HIGH", role:"PROJECT_MANAGER"},
        ],
        milestones:[{name:"Beta complete", weekOffset:4}]
      },
      {name:"Launch & Growth", description:"Public launch, GTM execution, growth tracking", order:3, durationWeeks:4,
        tasks:[
          {title:"Launch marketing campaign", estimatedHours:40, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Product Hunt / press launch", estimatedHours:20, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"Customer support setup", estimatedHours:24, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Growth metrics dashboard", estimatedHours:16, priority:"MEDIUM", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Public launch", weekOffset:2},{name:"First 100 customers", weekOffset:4}]
      },
    ],
    riskCategories:[
      {name:"Product-market fit", examples:["Low activation","High churn"]},
      {name:"Technical debt", examples:["Scale issues at launch","Security vulnerabilities"]},
    ],
    documentTypes:["Product Brief","Sprint Plans","Beta Feedback Report","GTM Plan","Pricing Strategy","Launch Checklist"],
  },

  // ─── FINANCE ────────────────────────────────
  {
    id: "erp-implementation",
    name: "ERP System Implementation",
    description: "Full ERP deployment (SAP, Oracle, Dynamics 365) with data migration, training, and cutover.",
    longDescription: "Waterfall delivery covering blueprint, realization, testing, cutover, and hypercare. Pre-loaded with data migration tasks, integration checkpoints, parallel run phases, and change management deliverables.",
    methodology: "WATERFALL",
    industry: "Finance",
    category: "IT Implementation",
    icon: "💼",
    color: "#F59E0B",
    estimatedWeeks: 40,
    teamSize: "12–25 people",
    difficulty: "Advanced",
    tags: ["ERP","SAP","Oracle","Dynamics","Finance","ERP Implementation"],
    isPremium: true,
    price: 7900,
    usageCount: 178,
    rating: 4.9,
    ratingCount: 29,
    author: "ERPOps Consulting",
    featured: false,
    phases:[
      {name:"Project Preparation", description:"Project setup, standards, initial planning", order:0, durationWeeks:4,
        tasks:[
          {title:"Project scope & charter", estimatedHours:40, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"System landscape design", estimatedHours:60, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Data migration strategy", estimatedHours:40, priority:"HIGH", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Project kickoff", weekOffset:4}]
      },
      {name:"Blueprint", description:"Business process workshops, gap analysis, solution design", order:1, durationWeeks:10,
        tasks:[
          {title:"Business process workshops", estimatedHours:200, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Gap / fit analysis", estimatedHours:80, priority:"HIGH", role:"PROJECT_MANAGER"},
          {title:"Solution design document", estimatedHours:120, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Custom development spec", estimatedHours:60, priority:"HIGH", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Blueprint sign-off", weekOffset:10}]
      },
      {name:"Realization", description:"Configuration, development, unit testing", order:2, durationWeeks:16,
        tasks:[
          {title:"System configuration", estimatedHours:400, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Custom development", estimatedHours:200, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Data migration development", estimatedHours:160, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Integration development", estimatedHours:120, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Unit testing", estimatedHours:100, priority:"HIGH", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Realization complete", weekOffset:16}]
      },
      {name:"Final Preparation", description:"SIT, UAT, training, cutover preparation", order:3, durationWeeks:8,
        tasks:[
          {title:"System integration testing", estimatedHours:160, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"User acceptance testing", estimatedHours:120, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"End-user training", estimatedHours:200, priority:"HIGH", role:"TEAM_MEMBER"},
          {title:"Cutover plan & rehearsal", estimatedHours:60, priority:"CRITICAL", role:"PROJECT_MANAGER"},
        ],
        milestones:[{name:"Go/No-Go decision", weekOffset:8}]
      },
      {name:"Go-Live & Hypercare", description:"Production cutover, stabilization, hypercare support", order:4, durationWeeks:2,
        tasks:[
          {title:"Data migration cutover", estimatedHours:40, priority:"CRITICAL", role:"TEAM_MEMBER"},
          {title:"Go-live cutover", estimatedHours:20, priority:"CRITICAL", role:"PROJECT_MANAGER"},
          {title:"Hypercare support (30 days)", estimatedHours:120, priority:"HIGH", role:"TEAM_MEMBER"},
        ],
        milestones:[{name:"Go-live", weekOffset:1},{name:"Hypercare complete", weekOffset:2}]
      },
    ],
    riskCategories:[
      {name:"Data quality", examples:["Legacy data cleansing","Migration errors"]},
      {name:"Change management", examples:["User adoption","Process resistance"]},
      {name:"Integration", examples:["Third-party connector failures","API changes"]},
    ],
    documentTypes:["Business Blueprint","Solution Design","Test Scripts","Training Materials","Cutover Plan","Hypercare Report"],
  },
]

export const TEMPLATE_CATEGORIES = [
  { id:"all",          label:"All templates",  icon:"⭐" },
  { id:"featured",     label:"Featured",        icon:"🌟" },
  { id:"Healthcare",   label:"Healthcare",      icon:"🏥" },
  { id:"IT",           label:"IT & Technology", icon:"💻" },
  { id:"Construction", label:"Construction",    icon:"🏗" },
  { id:"Finance",      label:"Finance",         icon:"💼" },
  { id:"Compliance",   label:"Compliance",      icon:"🔒" },
  { id:"Technology",   label:"Software",        icon:"🚀" },
]

export const METHODOLOGY_FILTERS = [
  { id:"all",       label:"All methodologies" },
  { id:"WATERFALL", label:"Waterfall" },
  { id:"AGILE",     label:"Agile" },
  { id:"SCRUM",     label:"Scrum" },
]

export function getTemplate(id: string): TemplateDefinition | undefined {
  return TEMPLATE_LIBRARY.find(t => t.id === id)
}

export function filterTemplates(opts: {
  industry?:    string
  methodology?: string
  isPremium?:   boolean
  search?:      string
  featured?:    boolean
}): TemplateDefinition[] {
  return TEMPLATE_LIBRARY.filter(t => {
    if (opts.industry && opts.industry !== "all" && opts.industry !== "featured" && t.industry !== opts.industry) return false
    if (opts.industry === "featured" && !t.featured) return false
    if (opts.methodology && opts.methodology !== "all" && t.methodology !== opts.methodology) return false
    if (opts.isPremium !== undefined && t.isPremium !== opts.isPremium) return false
    if (opts.featured !== undefined && t.featured !== opts.featured) return false
    if (opts.search) {
      const q = opts.search.toLowerCase()
      return t.name.toLowerCase().includes(q)
          || t.description.toLowerCase().includes(q)
          || t.tags.some(tag => tag.toLowerCase().includes(q))
    }
    return true
  })
}
